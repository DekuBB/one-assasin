package com.example.data.model

enum class EquipSlot(val label: String, val iconEmoji: String) {
    WEAPON("Weapon", "🗡️"),
    HELMET("Helmet", "🪖"),
    ARMOR("Armor", "🥋"),
    GLOVES("Gloves", "🧤"),
    BOOTS("Boots", "🥾"),
    RING("Ring", "💍"),
    NECKLACE("Necklace", "📿"),
    RELIC("Relic", "🔮")
}

data class EquipmentItem(
    val id: String,
    val name: String,
    val slot: EquipSlot,
    val rarity: Rarity,
    val level: Int = 1,
    val baseAttack: Float = 0f,
    val baseDefense: Float = 0f,
    val baseHp: Float = 0f,
    val critChance: Float = 0f,
    val attackSpeedBonus: Float = 0f,
    val moveSpeedBonus: Float = 0f,
    val specialPerk: String = "",
    val iconEmoji: String = "🗡️"
) {
    val currentAttack: Float get() = baseAttack + (level - 1) * (baseAttack * 0.15f)
    val currentDefense: Float get() = baseDefense + (level - 1) * (baseDefense * 0.15f)
    val currentHp: Float get() = baseHp + (level - 1) * (baseHp * 0.15f)

    val upgradeGoldCost: Int get() = level * 80 + 50
    val upgradeStonesCost: Int get() = (level / 5) + 1
}

object EquipmentCatalog {
    val STARTER_ITEMS = listOf(
        EquipmentItem(
            id = "wep_shadow_dagger",
            name = "Shadow Dagger",
            slot = EquipSlot.WEAPON,
            rarity = Rarity.COMMON,
            baseAttack = 15f,
            critChance = 0.05f,
            specialPerk = "Backstab: +50% backstab damage",
            iconEmoji = "🗡️"
        ),
        EquipmentItem(
            id = "arm_assasin_cloak",
            name = "Stalker Cloak",
            slot = EquipSlot.ARMOR,
            rarity = Rarity.COMMON,
            baseDefense = 6f,
            baseHp = 25f,
            specialPerk = "+5% Dash Speed",
            iconEmoji = "🥋"
        ),
        EquipmentItem(
            id = "boot_shadow_treads",
            name = "Shadow Treads",
            slot = EquipSlot.BOOTS,
            rarity = Rarity.COMMON,
            moveSpeedBonus = 0.10f,
            baseDefense = 4f,
            iconEmoji = "🥾"
        ),
        EquipmentItem(
            id = "ring_iron_band",
            name = "Ring of Ferocity",
            slot = EquipSlot.RING,
            rarity = Rarity.COMMON,
            baseAttack = 8f,
            critChance = 0.04f,
            iconEmoji = "💍"
        )
    )

    val ALL_PRESETS = listOf(
        // Weapons
        EquipmentItem("wep_shadow_dagger", "Shadow Dagger", EquipSlot.WEAPON, Rarity.COMMON, baseAttack = 15f, critChance = 0.05f, specialPerk = "Backstab: +50% backstab damage", iconEmoji = "🗡️"),
        EquipmentItem("wep_iron_katana", "Iron Katana", EquipSlot.WEAPON, Rarity.UNCOMMON, baseAttack = 28f, attackSpeedBonus = 0.10f, specialPerk = "Slash: +15% AoE width", iconEmoji = "⚔️"),
        EquipmentItem("wep_void_blade", "Void Blade", EquipSlot.WEAPON, Rarity.RARE, baseAttack = 45f, critChance = 0.10f, specialPerk = "Void Pulse: Attacks release void shockwaves", iconEmoji = "🔮"),
        EquipmentItem("wep_crimson_reaper", "Crimson Reaper", EquipSlot.WEAPON, Rarity.EPIC, baseAttack = 70f, critChance = 0.15f, specialPerk = "Soul Siphon: +6% Life Steal", iconEmoji = "🩸"),
        EquipmentItem("wep_abyssal_edge", "Nightfall Dagger", EquipSlot.WEAPON, Rarity.LEGENDARY, baseAttack = 110f, critChance = 0.22f, attackSpeedBonus = 0.25f, specialPerk = "Assassin's Mark: Guaranteed Crit after Dash", iconEmoji = "✨"),
        
        // Armor
        EquipmentItem("arm_assasin_cloak", "Stalker Cloak", EquipSlot.ARMOR, Rarity.COMMON, baseDefense = 6f, baseHp = 25f, specialPerk = "+5% Dash Speed", iconEmoji = "🥋"),
        EquipmentItem("arm_carapace", "Shadow Carapace", EquipSlot.ARMOR, Rarity.UNCOMMON, baseDefense = 14f, baseHp = 50f, specialPerk = "-10% Hazard Damage", iconEmoji = "🛡️"),
        EquipmentItem("arm_blood_cuirass", "Blood Cuirass", EquipSlot.ARMOR, Rarity.RARE, baseDefense = 22f, baseHp = 90f, specialPerk = "Vengeance: Release thorns when struck", iconEmoji = "🎽"),
        EquipmentItem("arm_void_mantle", "Voidwalker Mantle", EquipSlot.ARMOR, Rarity.EPIC, baseDefense = 35f, baseHp = 150f, specialPerk = "Phase Shift: 15% chance to negate damage", iconEmoji = "🌌"),
        
        // Helmets
        EquipmentItem("helm_leather_hood", "Leather Hood", EquipSlot.HELMET, Rarity.COMMON, baseDefense = 4f, baseHp = 15f, iconEmoji = "🪖"),
        EquipmentItem("helm_shadow_mask", "Shadow Mask", EquipSlot.HELMET, Rarity.RARE, baseDefense = 15f, critChance = 0.08f, specialPerk = "Night Vision: See enemy telegraphs earlier", iconEmoji = "👺"),
        EquipmentItem("helm_crown_ruin", "Crown of Ruin", EquipSlot.HELMET, Rarity.LEGENDARY, baseDefense = 28f, baseAttack = 25f, critChance = 0.12f, specialPerk = "Overlord: +20% Boss Damage", iconEmoji = "👑"),

        // Gloves
        EquipmentItem("glove_cloth_wraps", "Cloth Wraps", EquipSlot.GLOVES, Rarity.COMMON, baseAttack = 5f, attackSpeedBonus = 0.05f, iconEmoji = "🧤"),
        EquipmentItem("glove_striker_mitts", "Striker Gauntlets", EquipSlot.GLOVES, Rarity.RARE, baseAttack = 18f, attackSpeedBonus = 0.15f, specialPerk = "Rapid Strike: Combo builds 2x faster", iconEmoji = "🥊"),

        // Boots
        EquipmentItem("boot_shadow_treads", "Shadow Treads", EquipSlot.BOOTS, Rarity.COMMON, moveSpeedBonus = 0.10f, baseDefense = 4f, iconEmoji = "🥾"),
        EquipmentItem("boot_wind_greaves", "Zephyr Greaves", EquipSlot.BOOTS, Rarity.EPIC, moveSpeedBonus = 0.25f, baseDefense = 16f, specialPerk = "Swift Dash: -25% Dash Cooldown", iconEmoji = "👟"),

        // Rings & Necklaces
        EquipmentItem("ring_iron_band", "Ring of Ferocity", EquipSlot.RING, Rarity.COMMON, baseAttack = 8f, critChance = 0.04f, iconEmoji = "💍"),
        EquipmentItem("ring_vampiric_seal", "Vampiric Seal", EquipSlot.RING, Rarity.EPIC, baseAttack = 24f, critChance = 0.10f, specialPerk = "+8% Life Steal on Crit", iconEmoji = "💎"),
        EquipmentItem("neck_bone_amulet", "Bone Talisman", EquipSlot.NECKLACE, Rarity.UNCOMMON, baseHp = 40f, baseDefense = 8f, iconEmoji = "📿"),
        EquipmentItem("neck_heart_abyss", "Heart of the Abyss", EquipSlot.NECKLACE, Rarity.LEGENDARY, baseHp = 120f, baseAttack = 30f, specialPerk = "Undying Will: Survive 1 lethal hit per run", iconEmoji = "🔮"),

        // Relics
        EquipmentItem("relic_ancient_coin", "Cursed Doubloon", EquipSlot.RELIC, Rarity.RARE, baseAttack = 15f, specialPerk = "+35% Gold from slain enemies", iconEmoji = "🪙"),
        EquipmentItem("relic_chrono_orb", "Chrono Hourglass", EquipSlot.RELIC, Rarity.MYTHIC, baseAttack = 40f, baseDefense = 20f, specialPerk = "Time Warp: All skill cooldowns reduced by 25%", iconEmoji = "⌛")
    )
}
