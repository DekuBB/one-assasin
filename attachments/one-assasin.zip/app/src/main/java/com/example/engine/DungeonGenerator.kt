package com.example.engine

import com.example.data.model.*
import kotlin.random.Random

object DungeonGenerator {
    fun generateDungeon(biome: Biome = Biome.FORGOTTEN_CITADEL, totalTiers: Int = 8): DungeonFloorPlan {
        val tiers = mutableListOf<List<DungeonNode>>()

        // Tier 0: Entrance / First Combat Room (3 enemies)
        val startNode = DungeonNode(
            floor = 0,
            index = 0,
            roomType = RoomType.COMBAT,
            biome = biome,
            nextNodeIndices = listOf(0, 1),
            isCurrent = true,
            enemyCount = 3
        )
        tiers.add(listOf(startNode))

        // Intermediate tiers (1 to totalTiers - 2)
        for (tier in 1 until totalTiers - 1) {
            val nodeCount = if (tier == 4) 1 else Random.nextInt(2, 4) // Tier 4 is Miniboss
            val tierNodes = mutableListOf<DungeonNode>()

            for (i in 0 until nodeCount) {
                val roomType = when {
                    tier == 4 -> RoomType.ELITE // Miniboss Blood Knight
                    tier == 1 -> if (i == 0) RoomType.COMBAT else RoomType.EVENT
                    tier == 2 -> if (i == 0) RoomType.TREASURE else RoomType.SHRINE
                    tier == 3 -> if (i == 0) RoomType.COMBAT else RoomType.SHOP
                    tier == 5 -> if (i == 0) RoomType.HEAL else RoomType.TRAP
                    tier == 6 -> if (i == 0) RoomType.ELITE else RoomType.SHOP
                    else -> RoomType.COMBAT
                }

                val enemyCount = when (roomType) {
                    RoomType.COMBAT -> 3 + tier
                    RoomType.ELITE -> 2 + (tier / 2)
                    RoomType.TRAP -> 2
                    else -> 0
                }

                val nextCount = if (tier == totalTiers - 2) listOf(0) else listOf(0, 1)

                tierNodes.add(
                    DungeonNode(
                        floor = tier,
                        index = i,
                        roomType = roomType,
                        biome = biome,
                        nextNodeIndices = nextCount,
                        enemyCount = enemyCount
                    )
                )
            }
            tiers.add(tierNodes)
        }

        // Final Tier: Boss Room (The Gatekeeper)
        val bossNode = DungeonNode(
            floor = totalTiers - 1,
            index = 0,
            roomType = RoomType.BOSS,
            biome = biome,
            nextNodeIndices = emptyList(),
            enemyCount = 1
        )
        tiers.add(listOf(bossNode))

        return DungeonFloorPlan(
            biome = biome,
            nodes = tiers,
            currentFloorIndex = 0,
            currentNodeIndex = 0
        )
    }
}
