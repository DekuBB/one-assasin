package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Immersive UI Theme Colors
val VoidBlack = Color(0xFF08080A)         // Deepest background
val ImmersiveBg = Color(0xFF0D0D12)       // Arena & Canvas base
val ObsidianDark = Color(0xFF121216)      // Header & Primary Glass Panels
val DungeonSlate = Color(0xFF1A1A20)      // Cards & Bottom Controls Panel
val DungeonBorder = Color(0xFF272730)     // Default card borders
val BorderSubtle = Color(0x14FFFFFF)      // border-white/5
val BorderLight = Color(0x24FFFFFF)       // border-white/10
val BorderMedium = Color(0x40FFFFFF)      // border-white/25

// High-Contrast Neon Accent Colors
val CyanGlow = Color(0xFF06B6D4)          // Cyan-500
val NeonCyan = Color(0xFF22D3EE)          // Cyan-400
val CyanDark = Color(0x3306B6D4)          // Cyan-900/40
val ElectricBlue = Color(0xFF2563EB)      // Blue-600
val SkyAccent = Color(0xFF38BDF8)         // Sky-400

val CrimsonBlade = Color(0xFFE11D48)      // Rose-600
val RoseGlow = Color(0xFFFB7185)          // Rose-400
val RoseDark = Color(0x4DE11D48)          // Rose-900/60
val BloodDark = Color(0xFF881337)         // Rose-950

val GoldSun = Color(0xFFEAB308)           // Yellow-500
val YellowGlow = Color(0xFFFACC15)        // Yellow-400
val AmberGlow = Color(0xFFF59E0B)         // Amber-500
val FlameOrange = Color(0xFFF97316)       // Orange-500

val VoidAmethyst = Color(0xFFA855F7)      // Purple-500
val VoidPurple = Color(0xFF7C3AED)        // Violet-600
val EmeraldGreen = Color(0xFF10B981)      // Emerald-500
val PoisonGreen = Color(0xFF84CC16)       // Lime-500
val FrostCyan = Color(0xFF38BDF8)         // Sky-400

// Text & Neutral Tones
val TextWhite = Color(0xFFE2E2E7)         // Primary text
val TextMuted = Color(0xFF71717A)         // Zinc-500
val TextDark = Color(0xFF3F3F46)          // Zinc-700
val Zinc800 = Color(0xFF27272A)           // Button surface
val Zinc900 = Color(0xFF18181B)           // Bar track & joystick background

// Rarity Colors
val RarityCommon = Color(0xFFA1A1AA)
val RarityUncommon = Color(0xFF22C55E)
val RarityRare = Color(0xFF3B82F6)
val RarityEpic = Color(0xFFA855F7)
val RarityLegendary = Color(0xFFF59E0B)
val RarityMythic = Color(0xFFF43F5E)
val RarityForbidden = Color(0xFF06B6D4)
