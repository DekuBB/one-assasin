package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppNavState
import com.example.ui.GameViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HubScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "CAMPFIRE HAVEN",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        letterSpacing = 1.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(AppNavState.MAIN_MENU) },
                        modifier = Modifier.testTag("btn_hub_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextWhite
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianDark,
                    titleContentColor = TextWhite
                )
            )
        },
        containerColor = VoidBlack
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Campfire Centerpiece
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = ObsidianDark),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.verticalGradient(listOf(FlameOrange, AmberGlow))
                )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(FlameOrange.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🔥", fontSize = 36.sp)
                    }
                    Text(
                        text = "The Eternal Hearth",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldSun
                    )
                    Text(
                        text = "Rest your blades, converse with allies, forge gear, and prepare for the next descent.",
                        fontSize = 12.sp,
                        color = TextMuted,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            // Interactive Hub Stations
            HubStationCard(
                title = "Campfire Gathering",
                subtitle = "Select & Upgrade Assassins (Roster)",
                icon = "🥷",
                accentColor = CrimsonBlade,
                onClick = { viewModel.navigateTo(AppNavState.HERO_SELECT) },
                testTag = "hub_station_roster"
            )

            HubStationCard(
                title = "Blacksmith Forge",
                subtitle = "Upgrade weapons, armor & 3-to-1 Merge",
                icon = "🔨",
                accentColor = ElectricBlue,
                onClick = { viewModel.navigateTo(AppNavState.EQUIPMENT_FORGE) },
                testTag = "hub_station_forge"
            )

            HubStationCard(
                title = "Mystic's Archives",
                subtitle = "Browse 100+ Blessings & Secret Synergies",
                icon = "🔮",
                accentColor = VoidAmethyst,
                onClick = { viewModel.navigateTo(AppNavState.BLESSING_CODEX) },
                testTag = "hub_station_mystic"
            )

            HubStationCard(
                title = "Legacy Altar",
                subtitle = "Permanent talent tree upgrades",
                icon = "🌟",
                accentColor = GoldSun,
                onClick = { viewModel.navigateTo(AppNavState.LEGACY_ALTAR) },
                testTag = "hub_station_altar"
            )

            HubStationCard(
                title = "Bounty Notice Board",
                subtitle = "Daily missions & 50 achievements",
                icon = "📜",
                accentColor = EmeraldGreen,
                onClick = { viewModel.navigateTo(AppNavState.BOUNTY_ACHIEVEMENTS) },
                testTag = "hub_station_bounties"
            )

            // Portal
            Button(
                onClick = { viewModel.startNewRun() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("hub_btn_enter_dungeon"),
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonBlade),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("ENTER THE ABYSS PORTAL 🌀", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

@Composable
fun HubStationCard(
    title: String,
    subtitle: String,
    icon: String,
    accentColor: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DungeonSlate),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(listOf(accentColor.copy(alpha = 0.6f), Color.Transparent))
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = icon, fontSize = 22.sp)
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                Text(text = subtitle, fontSize = 11.sp, color = TextMuted)
            }

            Text("➔", color = accentColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}
