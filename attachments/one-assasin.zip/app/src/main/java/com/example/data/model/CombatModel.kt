package com.example.data.model

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

data class Projectile(
    val id: Long,
    var position: Offset,
    val velocity: Offset,
    val damage: Float,
    val isFromPlayer: Boolean,
    val radius: Float = 8f,
    val color: Color = NeonCyan,
    val maxLifetimeMs: Long = 3000L,
    var currentLifetimeMs: Long = 0L,
    val pierces: Boolean = false,
    val isHoming: Boolean = false
)

enum class DamageTextType {
    NORMAL,
    CRITICAL,
    BACKSTAB,
    HEAL,
    POISON,
    LIGHTNING,
    DODGE
}

data class FloatingText(
    val id: Long,
    val text: String,
    var position: Offset,
    val color: Color,
    val type: DamageTextType,
    val maxDurationMs: Long = 900L,
    var elapsedMs: Long = 0L
) {
    val progress: Float get() = (elapsedMs.toFloat() / maxDurationMs.toFloat()).coerceIn(0f, 1f)
    val alpha: Float get() = 1f - progress
}

data class CombatParticle(
    val id: Long,
    var position: Offset,
    val velocity: Offset,
    val color: Color,
    val size: Float,
    val maxDurationMs: Long = 400L,
    var elapsedMs: Long = 0L
) {
    val progress: Float get() = (elapsedMs.toFloat() / maxDurationMs.toFloat()).coerceIn(0f, 1f)
}

data class SlashEffect(
    val id: Long,
    val center: Offset,
    val angle: Float,
    val radius: Float,
    val color: Color,
    val maxDurationMs: Long = 200L,
    var elapsedMs: Long = 0L
) {
    val progress: Float get() = (elapsedMs.toFloat() / maxDurationMs.toFloat()).coerceIn(0f, 1f)
}

data class DecoyDecoy(
    val id: Long,
    val position: Offset,
    var timerMs: Long = 1500L
)
