package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.data.model.HeroId
import com.example.engine.EnemyType
import com.example.engine.GameEngine
import com.example.engine.GridEnemy
import kotlin.math.*
import kotlin.random.Random

@OptIn(ExperimentalTextApi::class)
@Composable
fun PixelArenaCanvas(
    engine: GameEngine,
    textMeasurer: TextMeasurer,
    screenShakeEnabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val canvasW = size.width
        val canvasH = size.height

        // Logical reference resolution: 405 x 720 (Guidus / One Assasin layout)
        val refW = 405f
        val refH = 720f

        val scale = minOf(canvasW / refW, canvasH / refH)
        val offsetX = (canvasW - refW * scale) / 2f
        val offsetY = (canvasH - refH * scale) / 2f

        val shakeX = if (screenShakeEnabled && engine.screenShakeAmount > 0f) {
            (Random.nextFloat() - 0.5f) * engine.screenShakeAmount
        } else 0f
        val shakeY = if (screenShakeEnabled && engine.screenShakeAmount > 0f) {
            (Random.nextFloat() - 0.5f) * engine.screenShakeAmount
        } else 0f

        withTransform({
            translate(offsetX + shakeX, offsetY + shakeY)
            scale(scale, scale, Offset.Zero)
        }) {
            val boardW = GameEngine.GRID_W * GameEngine.TILE_SIZE // 288f
            val boardH = GameEngine.GRID_H * GameEngine.TILE_SIZE // 352f
            val boardX = (refW - boardW) / 2f // 58.5f
            val boardY = 124f

            val now = System.currentTimeMillis()

            // 1. Draw Backdrop
            drawRect(
                color = Color(0xFF0D1325),
                size = Size(refW, refH)
            )

            // Subtle starry background grid dots
            for (py in 0..720 step 24) {
                for (px in 0..405 step 24) {
                    val wave = sin(px * 0.07f + py * 0.12f + now * 0.0006f)
                    if (wave > 0.85f) {
                        drawRect(
                            color = Color(0xFF151D35),
                            topLeft = Offset(px.toFloat(), py.toFloat()),
                            size = Size(2f, 2f)
                        )
                    }
                }
            }

            // Board Backdrop and Outer Metal Frame
            drawRect(
                color = Color(0xFF111A31),
                topLeft = Offset(10f, 107f),
                size = Size(refW - 20f, 386f)
            )
            drawRect(
                color = Color(0xFF46527A),
                topLeft = Offset(10f, 107f),
                size = Size(refW - 20f, 386f),
                style = Stroke(width = 2f)
            )

            // Clip Board Rendering
            clipRect(left = boardX, top = boardY, right = boardX + boardW, bottom = boardY + boardH) {
                val isGarden = engine.level % 3 == 2

                // 2. Draw Floor & Wall Tiles
                for (gy in 0 until GameEngine.GRID_H) {
                    for (gx in 0 until GameEngine.GRID_W) {
                        val tileX = boardX + gx * GameEngine.TILE_SIZE
                        val tileY = boardY + gy * GameEngine.TILE_SIZE
                        val isWall = engine.map[gy][gx] == 1

                        if (isWall) {
                            // Wall Stone Block
                            drawRect(Color(0xFF14182C), Offset(tileX, tileY), Size(GameEngine.TILE_SIZE, GameEngine.TILE_SIZE))
                            drawRect(Color(0xFF6D6670), Offset(tileX + 2f, tileY + 2f), Size(GameEngine.TILE_SIZE - 4f, GameEngine.TILE_SIZE - 4f))
                            drawRect(Color(0xFF8A7B73), Offset(tileX + 4f, tileY + 4f), Size(GameEngine.TILE_SIZE - 8f, 5f))
                            drawRect(Color(0xFF4A4858), Offset(tileX + 4f, tileY + 10f), Size(GameEngine.TILE_SIZE - 8f, GameEngine.TILE_SIZE - 14f))
                            drawRect(Color(0xFF333647), Offset(tileX + 4f, tileY + 20f), Size(GameEngine.TILE_SIZE - 8f, 2f))
                        } else {
                            // Floor Tile
                            val variant = (gx * 23 + gy * 13) % 3
                            val floorColor = if (isGarden) {
                                when (variant) {
                                    0 -> Color(0xFF526A46)
                                    1 -> Color(0xFF5C724D)
                                    else -> Color(0xFF465F42)
                                }
                            } else {
                                when (variant) {
                                    0 -> Color(0xFF56606F)
                                    1 -> Color(0xFF606675)
                                    else -> Color(0xFF4D596B)
                                }
                            }
                            drawRect(floorColor, Offset(tileX, tileY), Size(GameEngine.TILE_SIZE, GameEngine.TILE_SIZE))
                            // Tile borders
                            drawRect(if (isGarden) Color(0xFF74865B) else Color(0xFF7C7F89), Offset(tileX + 1f, tileY + 1f), Size(GameEngine.TILE_SIZE - 2f, 2f))
                            drawRect(if (isGarden) Color(0xFF324D38) else Color(0xFF3E4658), Offset(tileX + 1f, tileY + GameEngine.TILE_SIZE - 4f), Size(GameEngine.TILE_SIZE - 2f, 3f))
                        }
                    }
                }

                // 3. Draw Traps
                for (trap in engine.traps) {
                    val tx = boardX + trap.x * GameEngine.TILE_SIZE
                    val ty = boardY + trap.y * GameEngine.TILE_SIZE
                    drawRect(
                        if (trap.active) Color(0xFF9E5269) else Color(0xFF26364D),
                        Offset(tx + 8f, ty + 15f),
                        Size(16f, 6f)
                    )
                    if (trap.active) {
                        val pulse = sin(now * 0.009f + trap.pulse) * 2f
                        drawRect(Color(0xFFFF9379), Offset(tx + 11f, ty + 9f + pulse), Size(3f, 9f - pulse))
                        drawRect(Color(0xFFFF9379), Offset(tx + 18f, ty + 8f - pulse), Size(3f, 10f + pulse))
                    }
                }

                // 4. Draw Chests
                for (chest in engine.chests) {
                    val cx = boardX + chest.x * GameEngine.TILE_SIZE + 7f
                    val cy = boardY + chest.y * GameEngine.TILE_SIZE + 11f
                    drawRect(if (chest.open) Color(0xFF6F5A50) else Color(0xFFB77B45), Offset(cx, cy), Size(18f, 12f))
                    drawRect(Color(0xFFF2C95F), Offset(cx + 8f, cy), Size(3f, 12f))
                    if (!chest.open) {
                        drawRect(Color(0xFFE7A854), Offset(cx + 1f, cy - 3f), Size(16f, 4f))
                    }
                }

                // 5. Draw Exit Portal Door
                val ex = boardX + engine.exit.x * GameEngine.TILE_SIZE
                val ey = boardY + engine.exit.y * GameEngine.TILE_SIZE
                drawRect(Color(0xFF261B28), Offset(ex + 6f, ey + 3f), Size(20f, 28f))
                drawRect(Color(0xFF926045), Offset(ex + 8f, ey + 5f), Size(16f, 24f))
                drawRect(Color(0xFFD69B4A), Offset(ex + 10f, ey + 7f), Size(12f, 19f))
                drawRect(Color(0xFF44243C), Offset(ex + 13f, ey + 7f), Size(3f, 19f))
                drawRect(Color(0xFFFFDB76), Offset(ex + 20f, ey + 17f), Size(2f, 3f))

                // 6. Draw Enemies (sorted by Y for correct isometric depth)
                val sortedEnemies = engine.enemies.sortedBy { it.vy }
                for (enemy in sortedEnemies) {
                    drawGridEnemy(enemy, boardX, boardY, textMeasurer)
                }

                // 7. Draw Player Character
                val isBlinking = now < engine.invulnerableUntil && ((now / 70L) % 2L == 0L)
                if (!isBlinking) {
                    val heroPx = boardX + engine.playerVx * GameEngine.TILE_SIZE + 16f
                    val heroPy = boardY + engine.playerVy * GameEngine.TILE_SIZE + 17f

                    // Combat Tag over Player
                    drawCombatTag(
                        heroPx, heroPy - 17f,
                        "${engine.rank}",
                        engine.hp / engine.maxHp,
                        Color(0xFFEF626A),
                        textMeasurer
                    )

                    // Pixel Hero
                    drawPixelHero(heroPx, heroPy, engine.hero.id, engine.hero.primaryColor, engine.hero.glowColor)
                }

                // 8. Draw Wall Lanterns
                for (lantern in engine.lanterns) {
                    val lx = boardX + lantern.x * GameEngine.TILE_SIZE + 16f
                    val ly = boardY + lantern.y * GameEngine.TILE_SIZE + 14f
                    val flame = 1f + sin(now * 0.011f + lantern.flicker) * 0.35f

                    drawCircle(
                        color = Color(0x33EE8036),
                        radius = 18f * flame,
                        center = Offset(lx, ly)
                    )
                    drawRect(Color(0xFF442A30), Offset(lx - 5f, ly - 1f), Size(10f, 13f))
                    drawRect(Color(0xFFEF8B3E), Offset(lx - 3f, ly + 2f), Size(6f, 8f))
                    drawRect(Color(0xFFFFE57B), Offset(lx - 1f, ly + 4f), Size(2f, 4f))
                }

                // 9. Circular Fog of War Torchlight Mask
                val centerPlayerX = boardX + (engine.playerVx + 0.5f) * GameEngine.TILE_SIZE
                val centerPlayerY = boardY + (engine.playerVy + 0.5f) * GameEngine.TILE_SIZE

                val fogBrush = Brush.radialGradient(
                    0.0f to Color(0x00030D1F),
                    0.45f to Color(0x0A030D1F),
                    0.78f to Color(0x99030D1F),
                    1.0f to Color(0xEE030D1F),
                    center = Offset(centerPlayerX, centerPlayerY),
                    radius = GameEngine.TILE_SIZE * 4.4f
                )
                drawRect(
                    brush = fogBrush,
                    topLeft = Offset(boardX, boardY),
                    size = Size(boardW, boardH)
                )

                // 10. Draw Lightning Arcs (Supernova electrical shocks)
                for (arc in engine.lightningArcs) {
                    val startX = boardX + arc.startX * GameEngine.TILE_SIZE
                    val startY = boardY + arc.startY * GameEngine.TILE_SIZE
                    val endX = boardX + arc.endX * GameEngine.TILE_SIZE
                    val endY = boardY + arc.endY * GameEngine.TILE_SIZE

                    val midX = (startX + endX) / 2f + (Random.nextFloat() - 0.5f) * 16f
                    val midY = (startY + endY) / 2f + (Random.nextFloat() - 0.5f) * 16f

                    val path = Path().apply {
                        moveTo(startX, startY)
                        lineTo(midX, midY)
                        lineTo(endX, endY)
                    }
                    drawPath(
                        path = path,
                        color = arc.color.copy(alpha = (arc.life * 2.8f).coerceIn(0f, 1f)),
                        style = Stroke(width = 2.5f)
                    )
                }

                // 11. Draw Particles
                for (p in engine.particles) {
                    val px = boardX + p.x * GameEngine.TILE_SIZE
                    val py = boardY + p.y * GameEngine.TILE_SIZE
                    val alpha = (p.life * 2.2f).coerceIn(0f, 1f)
                    drawRect(
                        color = p.color.copy(alpha = alpha),
                        topLeft = Offset(px - 1.5f, py - 1.5f),
                        size = Size(3f, 3f)
                    )
                }

                // 12. Draw Floating Combat Text
                for (ft in engine.floatingTexts) {
                    val fx = boardX + (ft.x + 0.5f) * GameEngine.TILE_SIZE
                    val fy = boardY + (ft.y + 0.5f) * GameEngine.TILE_SIZE
                    val alpha = (ft.life * 1.5f).coerceIn(0f, 1f)

                    val textLayout = textMeasurer.measure(
                        text = AnnotatedString(ft.text),
                        style = TextStyle(
                            fontSize = if (ft.isCritical) 11.sp else 8.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = ft.color.copy(alpha = alpha)
                        )
                    )
                    // Drop shadow
                    val shadowLayout = textMeasurer.measure(
                        text = AnnotatedString(ft.text),
                        style = TextStyle(
                            fontSize = if (ft.isCritical) 11.sp else 8.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = Color.Black.copy(alpha = alpha * 0.8f)
                        )
                    )
                    drawText(shadowLayout, topLeft = Offset(fx - textLayout.size.width / 2f + 1f, fy - textLayout.size.height / 2f + 1f))
                    drawText(textLayout, topLeft = Offset(fx - textLayout.size.width / 2f, fy - textLayout.size.height / 2f))
                }
            }
        }
    }
}

private fun DrawScope.drawGridEnemy(
    enemy: GridEnemy,
    boardX: Float,
    boardY: Float,
    textMeasurer: TextMeasurer
) {
    val ex = boardX + enemy.vx * GameEngine.TILE_SIZE + 16f
    val ey = boardY + enemy.vy * GameEngine.TILE_SIZE + 17f
    val s = enemy.size

    // Combat Health Tag above enemy
    drawCombatTag(
        ex, ey - 17f * s,
        if (enemy.type == EnemyType.BOSS) "!" else "Lv",
        enemy.hp / enemy.maxHp,
        if (enemy.type == EnemyType.BOSS) Color(0xFFD28BE9) else Color(0xFFF58A94),
        textMeasurer
    )

    withTransform({
        translate(ex, ey)
        scale(s, s, Offset.Zero)
    }) {
        val bodyColor = if (enemy.hitFlash > 0f) Color(0xFFFFF4E8) else enemy.color

        drawRect(Color(0xFF101526), Offset(-10f, 8f), Size(20f, 4f))
        drawRect(bodyColor, Offset(-8f, -4f), Size(16f, 15f))
        drawRect(if (enemy.type == EnemyType.BOSS) Color(0xFF4C254F) else Color(0xFF422744), Offset(-6f, -9f), Size(12f, 6f))
        drawRect(Color(0xFFF5D8BC), Offset(-5f, -2f), Size(10f, 7f))

        // Eyes
        drawRect(Color(0xFF251A31), Offset(-3f, 0f), Size(2f, 2f))
        drawRect(Color(0xFF251A31), Offset(2f, 0f), Size(2f, 2f))
        drawRect(if (enemy.type == EnemyType.BOSS) Color(0xFFF7D06B) else Color(0xFFFF9197), Offset(-3f, 0f), Size(1f, 1f))
        drawRect(if (enemy.type == EnemyType.BOSS) Color(0xFFF7D06B) else Color(0xFFFF9197), Offset(3f, 0f), Size(1f, 1f))

        // Feet
        drawRect(Color(0xFF27213A), Offset(-7f, 10f), Size(5f, 5f))
        drawRect(Color(0xFF27213A), Offset(2f, 10f), Size(5f, 5f))

        // Boss Crown / Horns
        if (enemy.type == EnemyType.BOSS || enemy.type == EnemyType.ELITE) {
            drawRect(Color(0xFFD1B760), Offset(-10f, -7f), Size(3f, 11f))
            drawRect(Color(0xFFD1B760), Offset(7f, -7f), Size(3f, 11f))
            drawRect(Color(0xFFFFD166), Offset(-5f, -12f), Size(10f, 4f))
        }
    }
}

private fun DrawScope.drawPixelHero(
    cx: Float,
    cy: Float,
    heroId: HeroId,
    heroColor: Color,
    heroGlow: Color
) {
    withTransform({
        translate(cx, cy)
    }) {
        val hair = when (heroId) {
            HeroId.NYRA -> Color(0xFFE16989)
            HeroId.TOR -> Color(0xFFDCE3EC)
            HeroId.LUMA -> Color(0xFFC58CF1)
            else -> Color(0xFFF6BD60)
        }
        val coat = when (heroId) {
            HeroId.NYRA -> Color(0xFF5D304E)
            HeroId.TOR -> Color(0xFF315576)
            HeroId.LUMA -> Color(0xFF4B3B78)
            else -> Color(0xFF6B3A28)
        }

        // Shadow
        drawRect(Color(0xFF101426), Offset(-10f, 8f), Size(20f, 4f))
        // Coat
        drawRect(coat, Offset(-8f, -3f), Size(16f, 15f))
        // Shirt / Armor
        drawRect(heroColor, Offset(-6f, 4f), Size(12f, 9f))
        // Face skin
        drawRect(Color(0xFFF6D8BE), Offset(-5f, -4f), Size(10f, 9f))
        // Hair
        drawRect(hair, Offset(-6f, -8f), Size(12f, 6f))
        drawRect(hair, Offset(-7f, -4f), Size(3f, 5f))
        // Eyes
        drawRect(Color(0xFF24233A), Offset(-3f, -1f), Size(2f, 2f))
        drawRect(Color(0xFF24233A), Offset(2f, -1f), Size(2f, 2f))
        drawRect(heroGlow, Offset(-2f, -1f), Size(1f, 1f))
        drawRect(heroGlow, Offset(2f, -1f), Size(1f, 1f))
        // Boots
        drawRect(Color(0xFF211D30), Offset(-7f, 10f), Size(5f, 5f))
        drawRect(Color(0xFF211D30), Offset(2f, 10f), Size(5f, 5f))
        // Weapon
        drawRect(Color(0xFFE8BF7C), Offset(7f, -4f), Size(5f, 2f))
        drawRect(Color(0xFFE8BF7C), Offset(9f, -6f), Size(2f, 8f))

        // Shield for Tor
        if (heroId == HeroId.TOR) {
            drawRect(Color(0xFF7BD2E6), Offset(-12f, 1f), Size(4f, 9f))
            drawRect(Color(0xFF7BD2E6), Offset(-13f, 3f), Size(6f, 5f))
        }
        // Wand / Staff for Luma
        if (heroId == HeroId.LUMA) {
            drawRect(Color(0xFFCBEAFE), Offset(-11f, -2f), Size(3f, 3f))
            drawRect(Color(0xFFCBEAFE), Offset(-13f, -3f), Size(2f, 1f))
        }
    }
}

private fun DrawScope.drawCombatTag(
    x: Float,
    y: Float,
    rankText: String,
    healthPercent: Float,
    barColor: Color,
    textMeasurer: TextMeasurer
) {
    // Black border tag
    drawRect(Color(0xFF111527), Offset(x - 14f, y - 7f), Size(28f, 8f))
    drawRect(Color(0xFFF1EFE4), Offset(x - 13f, y - 6f), Size(9f, 6f))

    val layout = textMeasurer.measure(
        text = AnnotatedString(rankText),
        style = TextStyle(
            fontSize = 6.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF25263B)
        )
    )
    drawText(layout, topLeft = Offset(x - 12f, y - 6.5f))

    // Health bar fill
    drawRect(Color(0xFF432936), Offset(x - 3f, y - 6f), Size(16f, 6f))
    val fillW = (15f * healthPercent.coerceIn(0f, 1f)).coerceAtLeast(1f)
    drawRect(barColor, Offset(x - 2.5f, y - 5.5f), Size(fillW, 5f))
}
