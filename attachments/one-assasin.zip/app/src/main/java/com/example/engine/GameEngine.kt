package com.example.engine

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.example.data.model.*
import com.example.ui.theme.*
import kotlin.math.*
import kotlin.random.Random

enum class Direction(val dx: Int, val dy: Int, val icon: String) {
    UP(0, -1, "▲"),
    DOWN(0, 1, "▼"),
    LEFT(-1, 0, "◀"),
    RIGHT(1, 0, "▶")
}

enum class GameScreenState {
    PLAYING,
    BLESSING_UPGRADE_CHOICE,
    ARCHMAGE_KARMA_ALTAR,
    VICTORY,
    DEFEAT
}

enum class EnemyType(val title: String, val baseHp: Float, val baseAttack: Float, val color: Color, val delayMs: Long, val xp: Int, val size: Float) {
    MINION("Cień", 28f, 8f, Color(0xFFD2617A), 640L, 9, 1.0f),
    ELITE("Upiorny rycerz", 58f, 12f, Color(0xFFF0A65A), 510L, 18, 1.15f),
    BOSS("Strażnik Pałacu", 190f, 16f, Color(0xFFBF75F4), 475L, 52, 1.45f)
}

data class GridEnemy(
    val id: String,
    var x: Int,
    var y: Int,
    var vx: Float,
    var vy: Float,
    val type: EnemyType,
    val name: String,
    var hp: Float,
    val maxHp: Float,
    val attack: Float,
    val color: Color,
    val delayMs: Long,
    val xp: Int,
    val size: Float,
    var nextMoveAt: Long,
    var hitFlash: Float = 0f
)

data class GridTrap(
    val x: Int,
    val y: Int,
    var active: Boolean = true,
    var pulse: Float = 0f
)

data class GridChest(
    val x: Int,
    val y: Int,
    var open: Boolean = false
)

data class GridLantern(
    val x: Int,
    val y: Int,
    var flicker: Float = 0f
)

data class CombatFloatingText(
    val text: String,
    var x: Float,
    var y: Float,
    val color: Color,
    var life: Float = 1.0f,
    val isCritical: Boolean = false
)

data class GridParticle(
    var x: Float,
    var y: Float,
    val dx: Float,
    val dy: Float,
    val color: Color,
    var life: Float,
    val maxLife: Float
)

data class LightningArc(
    val startX: Float,
    val startY: Float,
    val endX: Float,
    val endY: Float,
    val color: Color,
    var life: Float = 0.35f
)

class GameEngine(
    val hero: HeroDefinition,
    val heroLevel: Int = 1,
    val heroStar: Int = 1,
    val equippedItems: List<EquipmentItem> = emptyList(),
    val legacyUpgrades: Map<String, Int> = emptyMap(),
    val audioSynth: AudioSynth? = null,
    val onVibrate: ((Long) -> Unit)? = null
) {
    companion object {
        const val GRID_W = 9
        const val GRID_H = 11
        const val TILE_SIZE = 32f
    }

    var state = GameScreenState.PLAYING
    var level = 1 // Floor 1 to 10
    val maxLevel = 10

    // Grid Map: 1 = Wall, 0 = Walkable Floor
    var map = Array(GRID_H) { IntArray(GRID_W) }
    var exit = Offset(4f, 1f)

    // Player Grid State
    var playerX = 4
    var playerY = 9
    var playerVx = 4f
    var playerVy = 9f

    // Hero Core Stats
    var maxHp = hero.baseHp
    var hp = hero.baseHp
    var attack = hero.baseAttack
    var armor = hero.baseDefense
    var moveDelay = hero.moveDelayMs
    var critChance = hero.baseCritChance
    var critDamage = hero.baseCritDamage
    var skillPower = 1.0f

    // Resources & Progress
    var souls = 0
    var gold = 0
    var keys = 1
    var pickaxes = 10
    var karma = 0
    var relics = 0
    var kills = 0
    var rank = 1
    var xp = 0
    var nextXp = 28

    // Active 3x3 (9 slots) Blessings
    val equippedBlessings = arrayOfNulls<Blessing>(9)
    val allActiveBlessings = mutableListOf<Blessing>()

    // Entities in current dungeon room
    val enemies = mutableListOf<GridEnemy>()
    val traps = mutableListOf<GridTrap>()
    val chests = mutableListOf<GridChest>()
    val lanterns = mutableListOf<GridLantern>()
    val particles = mutableListOf<GridParticle>()
    val floatingTexts = mutableListOf<CombatFloatingText>()
    val lightningArcs = mutableListOf<LightningArc>()

    // Control & Cooldown Timers
    var heldDirection: Direction? = null
    var lastDirection: Direction = Direction.UP
    var nextPlayerMoveAt: Long = 0L
    var primaryReadyAt: Long = 0L
    var secondaryReadyAt: Long = 0L
    var invulnerableUntil: Long = 0L
    var screenShakeAmount = 0f

    // Upgrade Dialog Options
    var upgradeChoices = listOf<Blessing>()

    init {
        // Apply legacy and equipment bonuses
        val equipAtk = equippedItems.sumOf { it.currentAttack.toDouble() }.toFloat()
        val equipDef = equippedItems.sumOf { it.currentDefense.toDouble() }.toFloat()
        val equipHp = equippedItems.sumOf { it.currentHp.toDouble() }.toFloat()
        val equipCrit = equippedItems.sumOf { it.critChance.toDouble() }.toFloat()

        maxHp = hero.baseHp + equipHp + (heroLevel - 1) * 6f + (heroStar - 1) * 12f
        hp = maxHp
        attack = hero.baseAttack + equipAtk + (heroLevel - 1) * 2f + (heroStar - 1) * 4f
        armor = hero.baseDefense + equipDef
        critChance = (hero.baseCritChance + equipCrit).coerceIn(0.05f, 0.85f)
        moveDelay = hero.moveDelayMs

        createLevel()
    }

    fun createLevel() {
        enemies.clear()
        traps.clear()
        chests.clear()
        lanterns.clear()
        particles.clear()
        floatingTexts.clear()
        lightningArcs.clear()

        val isBossFloor = level % 3 == 0 || level == maxLevel
        val safeSpawn = listOf(
            Offset(4f, 9f), Offset(4f, 8f), Offset(3f, 9f), Offset(5f, 9f)
        )

        var generatedMap = Array(GRID_H) { IntArray(GRID_W) }
        var exitPos = Offset(4f, 1f)

        // Generate connected labyrinth
        for (attempt in 0 until 30) {
            val wallChance = (0.10f + level * 0.008f).coerceAtMost(0.22f)
            generatedMap = Array(GRID_H) { y ->
                IntArray(GRID_W) { x ->
                    if (x == 0 || y == 0 || x == GRID_W - 1 || y == GRID_H - 1) 1
                    else if (Random.nextFloat() < wallChance) 1 else 0
                }
            }
            exitPos = Offset(Random.nextInt(2, GRID_W - 2).toFloat(), 1f)
            (safeSpawn + listOf(exitPos, Offset(exitPos.x, 2f))).forEach { pt ->
                generatedMap[pt.y.toInt()][pt.x.toInt()] = 0
            }
            if (isPathReachable(generatedMap, Offset(4f, 9f), exitPos)) {
                break
            }
        }

        map = generatedMap
        exit = exitPos
        playerX = 4
        playerY = 9
        playerVx = 4f
        playerVy = 9f

        // Spawn Enemies
        val enemyCount = if (isBossFloor) 3 + level else 4 + level * 2
        for (i in 0 until enemyCount) {
            val freeCell = findRandomFreeCell(minDistFromPlayer = 3) ?: continue
            val isElite = !isBossFloor && level >= 2 && Random.nextFloat() < 0.22f
            val type = if (isElite) EnemyType.ELITE else EnemyType.MINION
            enemies.add(createEnemy(freeCell.x.toInt(), freeCell.y.toInt(), type))
        }

        // Spawn Boss
        if (isBossFloor) {
            val bossPos = findRandomFreeCell(minDistFromPlayer = 4) ?: Offset(4f, 4f)
            enemies.add(createEnemy(bossPos.x.toInt(), bossPos.y.toInt(), EnemyType.BOSS))
            addFloating("👑 STRAŻNIK PAŁACU", bossPos.x, bossPos.y - 0.8f, Color(0xFFFF9D78))
        }

        // Spawn Traps
        val trapCount = 2 + level / 2
        for (i in 0 until trapCount) {
            val cell = findRandomFreeCell(minDistFromPlayer = 2) ?: continue
            traps.add(GridTrap(cell.x.toInt(), cell.y.toInt(), active = true, pulse = Random.nextFloat() * 6.28f))
        }

        // Spawn Chests
        val chestCount = if (isBossFloor) 2 else 1
        for (i in 0 until chestCount) {
            val cell = findRandomFreeCell(minDistFromPlayer = 2) ?: continue
            chests.add(GridChest(cell.x.toInt(), cell.y.toInt(), open = false))
        }

        // Spawn Wall Lanterns/Torches
        for (i in 0 until 4) {
            val cell = findRandomFreeCell(minDistFromPlayer = 1) ?: continue
            lanterns.add(GridLantern(cell.x.toInt(), cell.y.toInt(), flicker = Random.nextFloat() * 6.28f))
        }

        addFloating("POZIOM $level - LOCH", 4f, 5f, Color(0xFF8EE7E2))
    }

    private fun isPathReachable(grid: Array<IntArray>, start: Offset, target: Offset): Boolean {
        val queue = ArrayDeque<Offset>()
        val visited = mutableSetOf<String>()
        queue.add(start)
        visited.add("${start.x.toInt()}:${start.y.toInt()}")

        while (queue.isNotEmpty()) {
            val current = queue.removeFirst()
            if (current.x.toInt() == target.x.toInt() && current.y.toInt() == target.y.toInt()) {
                return true
            }
            for (dir in Direction.values()) {
                val nx = current.x.toInt() + dir.dx
                val ny = current.y.toInt() + dir.dy
                val key = "$nx:$ny"
                if (nx in 1 until GRID_W - 1 && ny in 1 until GRID_H - 1 && grid[ny][nx] == 0 && !visited.contains(key)) {
                    visited.add(key)
                    queue.add(Offset(nx.toFloat(), ny.toFloat()))
                }
            }
        }
        return false
    }

    private fun findRandomFreeCell(minDistFromPlayer: Int): Offset? {
        val candidates = mutableListOf<Offset>()
        for (y in 1 until GRID_H - 1) {
            for (x in 1 until GRID_W - 1) {
                if (map[y][x] != 0 || (x == exit.x.toInt() && y == exit.y.toInt())) continue
                val occupied = enemies.any { it.x == x && it.y == y } ||
                        chests.any { it.x == x && it.y == y } ||
                        traps.any { it.x == x && it.y == y }
                val dist = abs(x - playerX) + abs(y - playerY)
                if (!occupied && dist >= minDistFromPlayer) {
                    candidates.add(Offset(x.toFloat(), y.toFloat()))
                }
            }
        }
        return if (candidates.isNotEmpty()) candidates.random() else null
    }

    private fun createEnemy(x: Int, y: Int, type: EnemyType): GridEnemy {
        val hpMult = 1f + (level - 1) * 0.25f
        val atkMult = 1f + (level - 1) * 0.18f
        val eHp = type.baseHp * hpMult
        val eAtk = type.baseAttack * atkMult
        return GridEnemy(
            id = "enemy_${Random.nextInt(100000)}",
            x = x,
            y = y,
            vx = x.toFloat(),
            vy = y.toFloat(),
            type = type,
            name = type.title,
            hp = eHp,
            maxHp = eHp,
            attack = eAtk,
            color = type.color,
            delayMs = type.delayMs,
            xp = type.xp,
            size = type.size,
            nextMoveAt = System.currentTimeMillis() + Random.nextLong(100, 500)
        )
    }

    fun isWalkable(x: Int, y: Int): Boolean {
        return x in 0 until GRID_W && y in 0 until GRID_H && map[y][x] == 0
    }

    fun enemyAt(x: Int, y: Int): GridEnemy? {
        return enemies.find { it.x == x && it.y == y }
    }

    fun movePlayer(direction: Direction) {
        if (state != GameScreenState.PLAYING) return
        val now = System.currentTimeMillis()
        if (now < nextPlayerMoveAt) return

        lastDirection = direction
        nextPlayerMoveAt = now + moveDelay

        val targetX = playerX + direction.dx
        val targetY = playerY + direction.dy

        if (!isWalkable(targetX, targetY)) {
            addParticles(playerX.toFloat(), playerY.toFloat(), Color(0xFF596987), 4)
            audioSynth?.playHitSound()
            return
        }

        val targetEnemy = enemyAt(targetX, targetY)
        if (targetEnemy != null) {
            // Bump combat attack
            performBasicAttack(targetEnemy)
            return
        }

        // Move to empty tile
        playerX = targetX
        playerY = targetY
        audioSynth?.playDashSound()
        onEnterTile()
    }

    fun performBasicAttack(targetEnemy: GridEnemy) {
        val isCrit = Random.nextFloat() < critChance
        val dmg = (attack * (if (isCrit) critDamage else 1.0f)).roundToInt()
        damageEnemy(targetEnemy, dmg.toFloat(), fromSkill = false, isCrit = isCrit)
    }

    fun damageEnemy(enemy: GridEnemy, amount: Float, fromSkill: Boolean, isCrit: Boolean = false) {
        if (!enemies.contains(enemy)) return
        enemy.hp -= amount
        enemy.hitFlash = 1.0f
        screenShakeAmount = if (isCrit) 8f else 4f
        onVibrate?.invoke(if (isCrit) 40L else 20L)
        audioSynth?.playSlashSound()

        val text = if (isCrit) "KRYT! ${amount.toInt()}" else "${amount.toInt()}"
        val color = if (isCrit) Color(0xFFFFE47A) else if (fromSkill) Color(0xFF9EEEFF) else Color(0xFFFFF3ED)
        addFloating(text, enemy.x.toFloat(), enemy.y.toFloat() - 0.35f, color, isCrit)
        addParticles(enemy.x.toFloat(), enemy.y.toFloat(), if (fromSkill) Color(0xFF9EEEFF) else Color(0xFFF28A9C), if (isCrit) 16 else 8)

        if (enemy.hp <= 0f) {
            enemies.remove(enemy)
            kills++
            souls += (enemy.xp / 2).coerceAtLeast(1)
            gold += enemy.xp * 2
            gainXp(enemy.xp)
            audioSynth?.playKillSound()
            addFloating("POKONANY", enemy.x.toFloat(), enemy.y.toFloat(), Color(0xFF91E9C3))
            addParticles(enemy.x.toFloat(), enemy.y.toFloat(), Color(0xFFD9E8FF), if (enemy.type == EnemyType.BOSS) 30 else 14)
        }
    }

    fun gainXp(amount: Int) {
        xp += amount
        if (xp >= nextXp && state == GameScreenState.PLAYING) {
            xp -= nextXp
            rank++
            nextXp = (nextXp * 1.32f).roundToInt()
            audioSynth?.playLevelUpSound()
            showBlessingChoices()
        }
    }

    fun showBlessingChoices() {
        state = GameScreenState.BLESSING_UPGRADE_CHOICE
        upgradeChoices = BlessingCatalog.ALL_STANDARD.shuffled().take(3)
    }

    fun chooseBlessing(blessing: Blessing) {
        applyBlessing(blessing)
        addFloating(blessing.name.uppercase(), playerX.toFloat(), playerY.toFloat() - 1f, Color(0xFFFFD67B))
        state = GameScreenState.PLAYING
    }

    fun applyBlessing(blessing: Blessing) {
        allActiveBlessings.add(blessing)

        // Insert into first empty slot in 3x3 grid
        val emptyIndex = equippedBlessings.indexOfFirst { it == null }
        if (emptyIndex != -1) {
            equippedBlessings[emptyIndex] = blessing
        }

        attack += blessing.attackBonus
        maxHp += blessing.hpBonus
        if (blessing.healAmount > 0f) {
            hp = (hp + blessing.healAmount).coerceAtMost(maxHp)
        }
        if (blessing.speedMultiplier < 1.0f) {
            moveDelay = (moveDelay * blessing.speedMultiplier).toLong().coerceAtLeast(70L)
        }
        critChance = (critChance + blessing.critBonus).coerceIn(0.05f, 0.85f)
        skillPower += blessing.skillPowerBonus
        armor += blessing.armorBonus
    }

    fun onEnterTile() {
        // Check Trap
        val trap = traps.find { it.active && it.x == playerX && it.y == playerY }
        if (trap != null) {
            trap.active = false
            takeDamage(13f + level * 2f, "PUŁAPKA")
            addParticles(trap.x.toFloat(), trap.y.toFloat(), Color(0xFFFF8C68), 12)
            audioSynth?.playHitSound()
        }

        // Check Chest
        val chest = chests.find { !it.open && it.x == playerX && it.y == playerY }
        if (chest != null) {
            chest.open = true
            val heal = 18f + level * 3f
            hp = (hp + heal).coerceAtMost(maxHp)
            souls += 7 + level * 2
            gold += 25 + level * 10
            relics++
            audioSynth?.playChestOpenSound()
            addFloating("+${heal.toInt()} ŻYCIA • RELIKT", chest.x.toFloat(), chest.y.toFloat(), Color(0xFF95F0A2))
            addParticles(chest.x.toFloat(), chest.y.toFloat(), Color(0xFFF5D36C), 16)
        }

        // Trigger Footstep Supernova
        triggerFootstepSupernova()

        // Check Exit Door
        if (playerX == exit.x.toInt() && playerY == exit.y.toInt()) {
            val hasBoss = enemies.any { it.type == EnemyType.BOSS }
            if (hasBoss) {
                addFloating("BOSS BLOKUJE PRZEJŚCIE", exit.x, exit.y - 0.65f, Color(0xFFFFAB93))
            } else {
                completeFloor()
            }
        }
    }

    fun triggerFootstepSupernova() {
        val baseChance = when (hero.id) {
            HeroId.LUMA -> 0.14f
            HeroId.NYRA -> 0.10f
            else -> 0.08f
        }
        val bonusChance = allActiveBlessings.sumOf { it.supernovaChanceBonus.toDouble() }.toFloat()
        val totalChance = baseChance + bonusChance

        if (Random.nextFloat() < totalChance && enemies.isNotEmpty()) {
            val victims = enemies.filter { abs(it.x - playerX) + abs(it.y - playerY) <= 2 }
            if (victims.isNotEmpty()) {
                val dmg = (attack * 0.75f * skillPower).roundToInt().toFloat()
                victims.forEach { enemy ->
                    damageEnemy(enemy, dmg, fromSkill = true)
                    lightningArcs.add(
                        LightningArc(
                            playerVx + 0.5f, playerVy + 0.5f,
                            enemy.vx + 0.5f, enemy.vy + 0.5f,
                            Color(0xFFFAE48C), 0.35f
                        )
                    )
                }
                audioSynth?.playEnergyBeamSound()
                addFloating("SUPERNOVA", playerX.toFloat(), playerY.toFloat() - 0.8f, Color(0xFFFAE48C))
                addParticles(playerX.toFloat(), playerY.toFloat(), Color(0xFFF4D873), 20)
            }
        }
    }

    fun takeDamage(amount: Float, sourceLabel: String = "CIEŃ") {
        val now = System.currentTimeMillis()
        if (now < invulnerableUntil || state != GameScreenState.PLAYING) return

        val applied = (amount - armor).coerceAtLeast(1f)
        hp -= applied
        invulnerableUntil = now + 420L
        screenShakeAmount = 10f
        onVibrate?.invoke(50L)
        audioSynth?.playHitSound()

        addFloating("-${applied.toInt()} $sourceLabel", playerX.toFloat(), playerY.toFloat() - 0.4f, Color(0xFFFF8C83))
        addParticles(playerX.toFloat(), playerY.toFloat(), Color(0xFFFF667D), 12)

        if (hp <= 0f) {
            hp = 0f
            state = GameScreenState.DEFEAT
            audioSynth?.playDefeatSound()
        }
    }

    fun usePrimarySkill() {
        if (state != GameScreenState.PLAYING) return
        val now = System.currentTimeMillis()
        if (now < primaryReadyAt) return

        when (hero.id) {
            HeroId.NYRA -> {
                // Skok cienia: Leap 2 tiles forward
                for (step in 1..2) {
                    val nextX = playerX + lastDirection.dx
                    val nextY = playerY + lastDirection.dy
                    if (!isWalkable(nextX, nextY)) break
                    val enemy = enemyAt(nextX, nextY)
                    if (enemy != null) {
                        damageEnemy(enemy, attack * 1.5f * skillPower, fromSkill = true, isCrit = true)
                    } else {
                        playerX = nextX
                        playerY = nextY
                    }
                }
                addFloating("SKOK CIENIA", playerX.toFloat(), playerY.toFloat() - 0.6f, hero.glowColor)
                addParticles(playerX.toFloat(), playerY.toFloat(), hero.glowColor, 18)
                audioSynth?.playSlashSound()
            }
            HeroId.TOR -> {
                // Uderzenie tarczą: Hit all adjacent enemies
                val targets = enemies.filter { abs(it.x - playerX) + abs(it.y - playerY) <= 1 }
                targets.forEach { damageEnemy(it, attack * 1.45f * skillPower, fromSkill = true) }
                addFloating("UDERZENIE RUN", playerX.toFloat(), playerY.toFloat() - 0.6f, hero.glowColor)
                addParticles(playerX.toFloat(), playerY.toFloat(), hero.glowColor, 22)
                audioSynth?.playHitSound()
            }
            HeroId.LUMA -> {
                // Promień gwiazd: 5-tile piercing beam
                for (step in 1..5) {
                    val beamX = playerX + lastDirection.dx * step
                    val beamY = playerY + lastDirection.dy * step
                    if (!isWalkable(beamX, beamY)) break
                    addParticles(beamX.toFloat(), beamY.toFloat(), hero.glowColor, 4)
                    val enemy = enemyAt(beamX, beamY)
                    if (enemy != null) {
                        damageEnemy(enemy, attack * 1.55f * skillPower, fromSkill = true)
                    }
                }
                addFloating("PROMIEŃ GWIAZD", playerX.toFloat(), playerY.toFloat() - 0.6f, hero.glowColor)
                audioSynth?.playEnergyBeamSound()
            }
            HeroId.BELPA -> {
                // Słoneczne cięcie: Burn area
                val targets = enemies.filter { abs(it.x - playerX) + abs(it.y - playerY) <= 2 }
                targets.forEach { damageEnemy(it, attack * 1.6f * skillPower, fromSkill = true) }
                addFloating("SŁONECZNE CIĘCIE", playerX.toFloat(), playerY.toFloat() - 0.6f, hero.glowColor)
                addParticles(playerX.toFloat(), playerY.toFloat(), hero.glowColor, 24)
                audioSynth?.playSlashSound()
            }
            else -> {
                val targets = enemies.filter { abs(it.x - playerX) + abs(it.y - playerY) <= 1 }
                targets.forEach { damageEnemy(it, attack * 1.5f * skillPower, fromSkill = true) }
            }
        }

        primaryReadyAt = now + hero.skill1.cooldownMs
    }

    fun useSecondarySkill() {
        if (state != GameScreenState.PLAYING) return
        val now = System.currentTimeMillis()
        if (now < secondaryReadyAt) return

        val range = if (hero.id == HeroId.LUMA) 4 else 2
        val dmgMult = if (hero.id == HeroId.TOR) 1.1f else 1.25f
        val targets = enemies.filter { abs(it.x - playerX) + abs(it.y - playerY) <= range }
        targets.forEach { damageEnemy(it, attack * dmgMult * skillPower, fromSkill = true) }

        val heal = if (hero.id == HeroId.TOR) 8f else 3f
        hp = (hp + heal).coerceAtMost(maxHp)

        addFloating(hero.skill2.name.uppercase(), playerX.toFloat(), playerY.toFloat() - 0.7f, hero.glowColor)
        addParticles(playerX.toFloat(), playerY.toFloat(), hero.glowColor, 28)
        audioSynth?.playEnergyBeamSound()

        secondaryReadyAt = now + hero.skill2.cooldownMs
    }

    fun completeFloor() {
        if (level >= maxLevel) {
            state = GameScreenState.VICTORY
            audioSynth?.playVictorySound()
            return
        }
        level++
        hp = (hp + 22f).coerceAtMost(maxHp)
        createLevel()
        audioSynth?.playTeleportSound()
    }

    fun update(dt: Float) {
        val now = System.currentTimeMillis()

        // Handle held movement
        if (state == GameScreenState.PLAYING && heldDirection != null) {
            movePlayer(heldDirection!!)
        }

        // Update Enemy positions and real-time AI
        if (state == GameScreenState.PLAYING) {
            for (enemy in enemies) {
                if (now >= enemy.nextMoveAt) {
                    enemy.nextMoveAt = now + enemy.delayMs
                    val dx = playerX - enemy.x
                    val dy = playerY - enemy.y
                    if (abs(dx) + abs(dy) == 1) {
                        // Adjacent attack
                        takeDamage(enemy.attack, if (enemy.type == EnemyType.BOSS) "BOSS" else "CIEŃ")
                    } else {
                        // Pathfinding step towards player
                        val candidates = if (abs(dx) > abs(dy)) {
                            listOf(Offset(sign(dx.toFloat()), 0f), Offset(0f, sign(dy.toFloat())))
                        } else {
                            listOf(Offset(0f, sign(dy.toFloat())), Offset(sign(dx.toFloat()), 0f))
                        }
                        for (c in candidates) {
                            val tx = enemy.x + c.x.toInt()
                            val ty = enemy.y + c.y.toInt()
                            val occupied = enemies.any { it != enemy && it.x == tx && it.y == ty }
                            if (isWalkable(tx, ty) && !occupied && !(tx == exit.x.toInt() && ty == exit.y.toInt())) {
                                enemy.x = tx
                                enemy.y = ty
                                break
                            }
                        }
                    }
                }
            }
        }

        // Smooth visual interpolation
        val lerpFactor = (dt * 14f).coerceIn(0f, 1f)
        playerVx += (playerX - playerVx) * lerpFactor
        playerVy += (playerY - playerVy) * lerpFactor

        for (enemy in enemies) {
            enemy.vx += (enemy.x - enemy.vx) * lerpFactor
            enemy.vy += (enemy.y - enemy.vy) * lerpFactor
            if (enemy.hitFlash > 0f) {
                enemy.hitFlash = (enemy.hitFlash - dt * 6f).coerceAtLeast(0f)
            }
        }

        screenShakeAmount = (screenShakeAmount - dt * 25f).coerceAtLeast(0f)

        // Update particles
        val pIter = particles.iterator()
        while (pIter.hasNext()) {
            val p = pIter.next()
            p.x += p.dx * dt
            p.y += p.dy * dt
            p.life -= dt
            if (p.life <= 0f) pIter.remove()
        }

        // Update floating texts
        val fIter = floatingTexts.iterator()
        while (fIter.hasNext()) {
            val f = fIter.next()
            f.y -= dt * 0.55f
            f.life -= dt
            if (f.life <= 0f) fIter.remove()
        }

        // Update lightning arcs
        val lIter = lightningArcs.iterator()
        while (lIter.hasNext()) {
            val arc = lIter.next()
            arc.life -= dt
            if (arc.life <= 0f) lIter.remove()
        }
    }

    fun addFloating(text: String, x: Float, y: Float, color: Color, isCrit: Boolean = false) {
        floatingTexts.add(CombatFloatingText(text, x, y, color, life = 1.0f, isCritical = isCrit))
    }

    fun addParticles(x: Float, y: Float, color: Color, count: Int) {
        for (i in 0 until count) {
            particles.add(
                GridParticle(
                    x = x + 0.5f,
                    y = y + 0.5f,
                    dx = (Random.nextFloat() - 0.5f) * 1.8f,
                    dy = (Random.nextFloat() - 0.5f) * 1.8f,
                    color = color,
                    life = 0.35f + Random.nextFloat() * 0.45f,
                    maxLife = 0.8f
                )
            )
        }
    }

    var runStartTimeMs: Long = System.currentTimeMillis()

    fun generateRunSummary(isVictory: Boolean): com.example.data.model.RunSummary {
        return com.example.data.model.RunSummary(
            heroName = hero.name,
            durationSeconds = ((System.currentTimeMillis() - runStartTimeMs).coerceAtLeast(1000L) / 1000L),
            enemiesDefeated = kills,
            bossesDefeated = if (isVictory) 3 else level / 3,
            totalDamageDealt = (kills * 45L + level * 120L),
            maxCombo = 1,
            goldCollected = gold,
            gemsCollected = if (isVictory) 10 else 2,
            blessingsCount = allActiveBlessings.size,
            finalScore = (kills * 100L + gold * 2L + level * 500L + if (isVictory) 5000L else 0L),
            isVictory = isVictory
        )
    }
}
