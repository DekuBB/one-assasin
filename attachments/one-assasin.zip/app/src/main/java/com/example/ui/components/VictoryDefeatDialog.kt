package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.engine.GameEngine
import com.example.ui.theme.*

@Composable
fun VictoryDefeatDialog(
    engine: GameEngine,
    isVictory: Boolean,
    onReturnToCamp: () -> Unit,
    onTryAgain: () -> Unit
) {
    val summary = engine.generateRunSummary(isVictory)
    val titleColor = if (isVictory) GoldSun else CrimsonBlade
    val titleText = if (isVictory) "👑 DUNGEON CLEARED 👑" else "💀 YOU DIED 💀"

    Dialog(onDismissRequest = {}) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = ObsidianDark),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.verticalGradient(
                    if (isVictory) listOf(GoldSun, NeonCyan) else listOf(CrimsonBlade, BloodDark)
                )
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = titleText,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = titleColor,
                    letterSpacing = 1.sp
                )

                // Stats breakdown
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DungeonSlate, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StatRow("Hero", summary.heroName, TextWhite)
                    StatRow("Run Time", "${summary.durationSeconds / 60}m ${summary.durationSeconds % 60}s", TextWhite)
                    StatRow("Enemies Defeated", "${summary.enemiesDefeated}", TextWhite)
                    StatRow("Bosses Defeated", "${summary.bossesDefeated}", titleColor)
                    StatRow("Max Combo", "${summary.maxCombo}x", GoldSun)
                    StatRow("Total Damage", "${summary.totalDamageDealt}", CrimsonBlade)
                    StatRow("Blessings Collected", "${summary.blessingsCount}", NeonCyan)
                    Divider(color = DungeonBorder, modifier = Modifier.padding(vertical = 4.dp))
                    StatRow("Gold Earned", "+${summary.goldCollected} 🪙", GoldSun)
                    StatRow("Gems Earned", "+${summary.gemsCollected} 💎", NeonCyan)
                    StatRow("FINAL SCORE", "${summary.finalScore} PTS", titleColor)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onReturnToCamp,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_return_camp"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("CAMP ⛺", fontSize = 12.sp, color = TextWhite)
                    }
                    Button(
                        onClick = onTryAgain,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_try_again"),
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonBlade),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("TRY AGAIN ⚔️", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = TextMuted)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
    }
}
