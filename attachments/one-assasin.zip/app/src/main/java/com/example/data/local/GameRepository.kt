package com.example.data.local

import android.content.Context
import androidx.room.Room
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class GameRepository(context: Context) {
    private val database = Room.databaseBuilder(
        context.applicationContext,
        AssasinDatabase::class.java,
        "one_assasin.db"
    ).build()

    private val dao = database.gameDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    init {
        scope.launch {
            seedInitialDataIfNeeded()
        }
    }

    val playerProfile: Flow<PlayerProfileEntity> = dao.getProfileFlow()
        .filterNotNull()
        .stateIn(
            scope = scope,
            started = SharingStarted.Eagerly,
            initialValue = PlayerProfileEntity()
        )

    val heroProgress: Flow<List<HeroProgressEntity>> = dao.getAllHeroProgressFlow()
        .stateIn(
            scope = scope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList()
        )

    val equipmentList: Flow<List<UserEquipmentEntity>> = dao.getAllEquipmentFlow()
        .stateIn(
            scope = scope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList()
        )

    val legacyUpgrades: Flow<List<UserLegacyEntity>> = dao.getLegacyUpgradesFlow()
        .stateIn(
            scope = scope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList()
        )

    val achievements: Flow<List<UserAchievementEntity>> = dao.getAchievementsFlow()
        .stateIn(
            scope = scope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList()
        )

    val runHistory: Flow<List<RunHistoryEntity>> = dao.getRunHistoryFlow()
        .stateIn(
            scope = scope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList()
        )

    private suspend fun seedInitialDataIfNeeded() {
        val currentProfile = dao.getProfileFlow().firstOrNull()
        if (currentProfile == null) {
            dao.saveProfile(
                PlayerProfileEntity(
                    id = 1,
                    selectedHeroId = "ZERO",
                    gold = 450,
                    gems = 60,
                    catalystStones = 3
                )
            )

            // Unlock Zero by default
            dao.saveHeroProgress(
                HeroProgressEntity(
                    heroId = HeroId.ZERO.name,
                    isUnlocked = true,
                    level = 1,
                    starRank = 1
                )
            )

            // Seed starter equipment
            val starters = EquipmentCatalog.STARTER_ITEMS.map { item ->
                UserEquipmentEntity(
                    instanceId = UUID.randomUUID().toString(),
                    itemPresetId = item.id,
                    slot = item.slot.name,
                    level = 1,
                    isEquipped = true
                )
            }
            dao.insertEquipment(starters)

            // Seed default legacy
            ProgressionCatalog.getDefaultLegacyUpgrades().forEach { legacy ->
                dao.saveLegacyUpgrade(UserLegacyEntity(legacy.id, 0))
            }

            // Seed achievements
            ProgressionCatalog.getDefaultAchievements().forEach { ach ->
                dao.saveAchievement(UserAchievementEntity(ach.id, 0, false))
            }
        }
    }

    suspend fun setSelectedHero(heroId: HeroId) {
        val current = dao.getProfileFlow().firstOrNull() ?: PlayerProfileEntity()
        dao.saveProfile(current.copy(selectedHeroId = heroId.name))
    }

    suspend fun unlockHero(heroId: HeroId, goldCost: Int, gemsCost: Int) {
        val current = dao.getProfileFlow().firstOrNull() ?: PlayerProfileEntity()
        if (current.gold >= goldCost && current.gems >= gemsCost) {
            dao.saveProfile(
                current.copy(
                    gold = current.gold - goldCost,
                    gems = current.gems - gemsCost
                )
            )
            dao.saveHeroProgress(
                HeroProgressEntity(
                    heroId = heroId.name,
                    isUnlocked = true,
                    level = 1,
                    starRank = 1
                )
            )
        }
    }

    suspend fun upgradeHeroLevel(heroId: HeroId, goldCost: Int) {
        val current = dao.getProfileFlow().firstOrNull() ?: PlayerProfileEntity()
        val heroes = dao.getAllHeroProgressFlow().firstOrNull() ?: emptyList()
        val targetHero = heroes.find { it.heroId == heroId.name } ?: return

        if (current.gold >= goldCost) {
            dao.saveProfile(current.copy(gold = current.gold - goldCost))
            dao.saveHeroProgress(targetHero.copy(level = targetHero.level + 1))
        }
    }

    suspend fun promoteHeroStar(heroId: HeroId, gemsCost: Int) {
        val current = dao.getProfileFlow().firstOrNull() ?: PlayerProfileEntity()
        val heroes = dao.getAllHeroProgressFlow().firstOrNull() ?: emptyList()
        val targetHero = heroes.find { it.heroId == heroId.name } ?: return

        if (current.gems >= gemsCost && targetHero.starRank < 5) {
            dao.saveProfile(current.copy(gems = current.gems - gemsCost))
            dao.saveHeroProgress(targetHero.copy(starRank = targetHero.starRank + 1))
        }
    }

    suspend fun upgradeLegacy(upgradeId: String, cost: Int) {
        val current = dao.getProfileFlow().firstOrNull() ?: PlayerProfileEntity()
        val legacyList = dao.getLegacyUpgradesFlow().firstOrNull() ?: emptyList()
        val currentLvl = legacyList.find { it.upgradeId == upgradeId }?.level ?: 0

        if (current.gold >= cost && currentLvl < 10) {
            dao.saveProfile(current.copy(gold = current.gold - cost))
            dao.saveLegacyUpgrade(UserLegacyEntity(upgradeId, currentLvl + 1))
        }
    }

    suspend fun upgradeEquipment(instanceId: String, costGold: Int, costStones: Int) {
        val current = dao.getProfileFlow().firstOrNull() ?: PlayerProfileEntity()
        val items = dao.getAllEquipmentFlow().firstOrNull() ?: emptyList()
        val target = items.find { it.instanceId == instanceId } ?: return

        if (current.gold >= costGold && current.catalystStones >= costStones && target.level < 50) {
            dao.saveProfile(
                current.copy(
                    gold = current.gold - costGold,
                    catalystStones = current.catalystStones - costStones
                )
            )
            val updated = items.map { if (it.instanceId == instanceId) it.copy(level = it.level + 1) else it }
            dao.insertEquipment(updated)
        }
    }

    suspend fun equipItem(instanceId: String) {
        val items = dao.getAllEquipmentFlow().firstOrNull() ?: emptyList()
        val target = items.find { it.instanceId == instanceId } ?: return

        val updated = items.map { item ->
            if (item.slot == target.slot) {
                item.copy(isEquipped = (item.instanceId == instanceId))
            } else {
                item
            }
        }
        dao.insertEquipment(updated)
    }

    suspend fun mergeEquipment(instanceIdsToConsume: List<String>, resultingPresetId: String, slot: String) {
        instanceIdsToConsume.forEach { dao.deleteEquipment(it) }
        dao.insertEquipment(
            listOf(
                UserEquipmentEntity(
                    instanceId = UUID.randomUUID().toString(),
                    itemPresetId = resultingPresetId,
                    slot = slot,
                    level = 1,
                    isEquipped = false
                )
            )
        )
    }

    suspend fun addLoot(items: List<UserEquipmentEntity>, gold: Int, gems: Int, stones: Int) {
        val current = dao.getProfileFlow().firstOrNull() ?: PlayerProfileEntity()
        dao.saveProfile(
            current.copy(
                gold = current.gold + gold,
                gems = current.gems + gems,
                catalystStones = current.catalystStones + stones
            )
        )
        if (items.isNotEmpty()) {
            dao.insertEquipment(items)
        }
    }

    suspend fun recordCompletedRun(summary: RunSummary) {
        val current = dao.getProfileFlow().firstOrNull() ?: PlayerProfileEntity()
        val newHighest = maxOf(current.highestScore, summary.finalScore)
        dao.saveProfile(
            current.copy(
                gold = current.gold + summary.goldCollected,
                gems = current.gems + summary.gemsCollected,
                totalRuns = current.totalRuns + 1,
                totalWins = current.totalWins + if (summary.isVictory) 1 else 0,
                totalKills = current.totalKills + summary.enemiesDefeated,
                highestScore = newHighest
            )
        )

        dao.insertRun(
            RunHistoryEntity(
                heroName = summary.heroName,
                durationSeconds = summary.durationSeconds,
                enemiesDefeated = summary.enemiesDefeated,
                bossesDefeated = summary.bossesDefeated,
                totalDamageDealt = summary.totalDamageDealt,
                maxCombo = summary.maxCombo,
                goldCollected = summary.goldCollected,
                gemsCollected = summary.gemsCollected,
                blessingsCount = summary.blessingsCount,
                finalScore = summary.finalScore,
                isVictory = summary.isVictory
            )
        )
    }

    suspend fun claimAchievement(achievementId: String, rewardGems: Int) {
        val current = dao.getProfileFlow().firstOrNull() ?: PlayerProfileEntity()
        dao.saveProfile(current.copy(gems = current.gems + rewardGems))
        dao.saveAchievement(UserAchievementEntity(achievementId, 999, true))
    }
}
