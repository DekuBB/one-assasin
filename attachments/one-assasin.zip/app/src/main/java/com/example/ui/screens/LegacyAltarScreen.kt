package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProgressionCatalog
import com.example.ui.AppNavState
import com.example.ui.GameViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LegacyAltarScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val allLegacies = ProgressionCatalog.getDefaultLegacyUpgrades()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("LEGACY OF THE ANCESTORS", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(AppNavState.HUB_WORLD) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianDark)
            )
        },
        containerColor = VoidBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = ObsidianDark),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.verticalGradient(listOf(GoldSun, VoidAmethyst)))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("🌟 PERMANENT TALENT TREE 🌟", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = GoldSun)
                        Text(
                            "Upgrades purchased here permanently strengthen ALL Assassins across all future runs.",
                            fontSize = 12.sp,
                            color = TextMuted,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Text(
                            "Current Gold: ${uiState.profile.gold} 🪙",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoldSun
                        )
                    }
                }
            }

            items(allLegacies) { legacy ->
                val currentLvl = uiState.legacyList.find { it.upgradeId == legacy.id }?.level ?: 0
                val cost = legacy.baseGoldCost + currentLvl * legacy.goldCostPerLevel
                val isMaxed = currentLvl >= legacy.maxLevel
                val canAfford = uiState.profile.gold >= cost && !isMaxed

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DungeonSlate),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(GoldSun.copy(alpha = 0.5f), DungeonBorder)))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(GoldSun.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(legacy.iconEmoji, fontSize = 22.sp)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(legacy.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                                Text("Lvl $currentLvl/${legacy.maxLevel}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldSun)
                            }
                            Text(legacy.description, fontSize = 11.sp, color = TextMuted)
                            Text(legacy.effectPerLevelString, fontSize = 11.sp, color = NeonCyan, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.upgradeLegacy(legacy.id) },
                            enabled = canAfford,
                            colors = ButtonDefaults.buttonColors(containerColor = if (canAfford) GoldSun else DungeonBorder),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                if (isMaxed) "MAX" else "$cost🪙",
                                fontSize = 11.sp,
                                color = if (canAfford) ObsidianDark else TextMuted,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
