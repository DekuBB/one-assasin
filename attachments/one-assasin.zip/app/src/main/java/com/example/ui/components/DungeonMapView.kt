package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.DungeonFloorPlan
import com.example.data.model.DungeonNode
import com.example.data.model.RoomType
import com.example.ui.theme.*

@Composable
fun DungeonMapView(
    dungeon: DungeonFloorPlan,
    onSelectNode: (floorIdx: Int, nodeIdx: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianDark),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.Brush.verticalGradient(listOf(NeonCyan, CrimsonBlade)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "🗺️ DUNGEON MAP",
                fontSize = 17.sp,
                fontWeight = FontWeight.ExtraBold,
                color = GoldSun
            )
            Text(
                text = "Biome: ${dungeon.biome.title} — Choose your next path",
                fontSize = 12.sp,
                color = TextMuted,
                textAlign = TextAlign.Center
            )

            // Floors
            val nextFloorIndex = dungeon.currentFloorIndex + 1
            val nextNodes = dungeon.nodes.getOrNull(nextFloorIndex) ?: emptyList()

            Text(
                text = "NEXT AVAILABLE ROOMS (Tier $nextFloorIndex):",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = NeonCyan
            )

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                nextNodes.forEachIndexed { nodeIdx, node ->
                    DungeonNodeItem(
                        node = node,
                        isClickable = true,
                        onClick = { onSelectNode(nextFloorIndex, nodeIdx) }
                    )
                }
            }
        }
    }
}

@Composable
fun DungeonNodeItem(
    node: DungeonNode,
    isClickable: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(DungeonSlate)
            .border(1.5.dp, node.roomType.color, RoundedCornerShape(10.dp))
            .then(if (isClickable) Modifier.clickable { onClick() } else Modifier)
            .padding(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(node.roomType.color.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = node.roomType.iconEmoji, fontSize = 20.sp)
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = node.roomType.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )
                Text(
                    text = node.roomType.description,
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }

            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = node.roomType.color),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("ENTER", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
