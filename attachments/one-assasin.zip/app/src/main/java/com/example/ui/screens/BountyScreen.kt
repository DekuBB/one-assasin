package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProgressionCatalog
import com.example.ui.AppNavState
import com.example.ui.GameViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BountyScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf(0) } // 0: Daily Missions, 1: Achievements

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("BOUNTY BOARD & GUILD TRIALS", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(AppNavState.HUB_WORLD) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianDark)
            )
        },
        containerColor = VoidBlack
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = ObsidianDark,
                contentColor = TextWhite
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("DAILY MISSIONS") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("50 ACHIEVEMENTS") })
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (selectedTab == 0) {
                    items(ProgressionCatalog.getDefaultDailyMissions()) { mission ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = DungeonSlate),
                            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(EmeraldGreen, DungeonBorder)))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(mission.iconEmoji, fontSize = 24.sp)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(mission.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                                    Text(mission.description, fontSize = 11.sp, color = TextMuted)
                                    Text("Reward: +${mission.rewardGold} 🪙 +${mission.rewardGems} 💎", fontSize = 11.sp, color = GoldSun)
                                }
                                Button(
                                    onClick = { },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("CLAIM", fontSize = 10.sp, color = ObsidianDark, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    items(ProgressionCatalog.getDefaultAchievements()) { ach ->
                        val userAch = uiState.achievementsList.find { it.achievementId == ach.id }
                        val isClaimed = userAch?.isClaimed ?: false

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = DungeonSlate),
                            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(GoldSun, DungeonBorder)))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(ach.iconEmoji, fontSize = 24.sp)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(ach.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                                    Text(ach.description, fontSize = 11.sp, color = TextMuted)
                                    Text("Reward: +${ach.rewardGems} 💎", fontSize = 11.sp, color = NeonCyan)
                                }
                                if (isClaimed) {
                                    Badge(containerColor = EmeraldGreen) {
                                        Text("CLAIMED", color = ObsidianDark, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                                    }
                                } else {
                                    Button(
                                        onClick = { viewModel.claimAchievement(ach) },
                                        colors = ButtonDefaults.buttonColors(containerColor = GoldSun),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("CLAIM", fontSize = 10.sp, color = ObsidianDark, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
