package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.EquipmentItem
import com.example.data.model.GameEvent
import com.example.data.model.GameEventChoice
import com.example.ui.theme.*

@Composable
fun EventChoiceDialog(
    event: GameEvent,
    onChoose: (GameEventChoice) -> Unit
) {
    Dialog(onDismissRequest = {}) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = ObsidianDark),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.Brush.verticalGradient(listOf(NeonCyan, VoidPurple)))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "${event.iconEmoji} ${event.title}",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = GoldSun
                )
                Text(
                    text = event.speaker,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonCyan
                )
                Text(
                    text = event.dialog,
                    fontSize = 13.sp,
                    color = TextWhite,
                    textAlign = TextAlign.Center,
                    lineHeight = 17.sp,
                    modifier = Modifier
                        .background(Color(0x33000000), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    event.choices.forEachIndexed { index, choice ->
                        Button(
                            onClick = { onChoose(choice) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("event_choice_$index"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DungeonSlate)
                        ) {
                            Text(
                                text = choice.text,
                                fontSize = 12.sp,
                                color = TextWhite,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BossChestDialog(
    rewards: List<EquipmentItem>,
    onSelectReward: (EquipmentItem) -> Unit
) {
    Dialog(onDismissRequest = {}) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = ObsidianDark),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.Brush.verticalGradient(listOf(GoldSun, CrimsonBlade)))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "👑 BOSS CHEST OPENED 👑",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = GoldSun
                )
                Text(
                    text = "Select 1 Legendary/Epic equipment reward to take home:",
                    fontSize = 12.sp,
                    color = TextMuted,
                    textAlign = TextAlign.Center
                )

                rewards.forEachIndexed { index, item ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(DungeonSlate)
                            .border(1.5.dp, item.rarity.color, RoundedCornerShape(12.dp))
                            .clickable { onSelectReward(item) }
                            .testTag("boss_reward_$index")
                            .padding(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(text = item.iconEmoji, fontSize = 28.sp)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                                Text(
                                    text = "${item.rarity.label} ${item.slot.label}",
                                    fontSize = 11.sp,
                                    color = item.rarity.color
                                )
                                Text(
                                    text = item.specialPerk,
                                    fontSize = 11.sp,
                                    color = GoldSun
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
