package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BlessingCatalog
import com.example.data.model.CurseCatalog
import com.example.ui.AppNavState
import com.example.ui.GameViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlessingCodexScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Standard Blessings, 1: Combine Synergies, 2: Curses

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("MYSTIC'S BLESSING CODEX", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(AppNavState.HUB_WORLD) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianDark)
            )
        },
        containerColor = VoidBlack
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = ObsidianDark,
                contentColor = TextWhite
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("BLESSINGS") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("SYNERGIES") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("CURSES") })
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        items(BlessingCatalog.ALL_STANDARD) { blessing ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = DungeonSlate),
                                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(blessing.rarity.color, DungeonBorder)))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(blessing.rarity.color.copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(blessing.iconEmoji, fontSize = 22.sp)
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(blessing.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                                            Text(blessing.rarity.label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = blessing.rarity.color)
                                        }
                                        Text(blessing.description, fontSize = 11.sp, color = TextMuted)
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        items(BlessingCatalog.SYNERGIES) { syn ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = ObsidianDark),
                                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(RarityForbidden, VoidPurple)))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(syn.synergyBlessing.iconEmoji, fontSize = 24.sp)
                                        Text(syn.name, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = RarityForbidden)
                                    }
                                    Text(
                                        text = "Requires: ${syn.requiredBlessingIds.joinToString(" + ") { it.replace('_', ' ') }}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GoldSun
                                    )
                                    Text(syn.description, fontSize = 11.sp, color = TextWhite)
                                }
                            }
                        }
                    }
                    2 -> {
                        items(CurseCatalog.ALL) { curse ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = DungeonSlate),
                                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(BloodDark, DungeonBorder)))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text("💀", fontSize = 24.sp)
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(curse.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CrimsonBlade)
                                        Text(curse.description, fontSize = 11.sp, color = TextMuted)
                                        Text("Penalty: ${curse.penaltyDescription}", fontSize = 11.sp, color = RoseGlow, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
