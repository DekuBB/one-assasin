package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.AppNavState
import com.example.ui.GameViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.VoidBlack

class MainActivity : ComponentActivity() {
    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: GameViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(VoidBlack)
    ) {
        AnimatedContent(
            targetState = uiState.navState,
            transitionSpec = {
                fadeIn() togetherWith fadeOut()
            },
            label = "screen_nav"
        ) { navState ->
            when (navState) {
                AppNavState.MAIN_MENU -> MainMenuScreen(viewModel = viewModel)
                AppNavState.HUB_WORLD -> HubScreen(viewModel = viewModel)
                AppNavState.HERO_SELECT -> HeroSelectScreen(viewModel = viewModel)
                AppNavState.EQUIPMENT_FORGE -> EquipmentScreen(viewModel = viewModel)
                AppNavState.BLESSING_CODEX -> BlessingCodexScreen(viewModel = viewModel)
                AppNavState.LEGACY_ALTAR -> LegacyAltarScreen(viewModel = viewModel)
                AppNavState.BOUNTY_ACHIEVEMENTS -> BountyScreen(viewModel = viewModel)
                AppNavState.SETTINGS -> SettingsScreen(viewModel = viewModel)
                AppNavState.IN_GAME -> GameScreen(viewModel = viewModel)
            }
        }
    }
}
