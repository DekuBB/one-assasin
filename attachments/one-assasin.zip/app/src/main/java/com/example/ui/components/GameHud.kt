package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.EnemyType
import com.example.engine.GameEngine
import com.example.ui.theme.*
import kotlin.math.ceil

@Composable
fun GameHud(
    engine: GameEngine,
    onOpenSettings: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val hero = engine.hero
    val boss = engine.enemies.find { it.type == EnemyType.BOSS }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // TOP BAR: Left Profile & Health, Center Boss Bar (if active), Right 3x3 Blessings
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            // TOP-LEFT: Karma Hero Banner & Bars
            Column(
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Ornate Metal Frame for Hero
                Row(
                    modifier = Modifier
                        .background(Color(0xFF10172A), RoundedCornerShape(8.dp))
                        .border(1.5.dp, Color(0xFF653842), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Level Badge
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF592F37))
                            .border(1.dp, Color(0xFFE05A5F), RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${engine.rank}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFEFF2E8)
                        )
                    }

                    Column(modifier = Modifier.width(112.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = hero.name.uppercase(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "${ceil(engine.hp).toInt()}/${engine.maxHp.toInt()}",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFFFE6D5)
                            )
                        }

                        // Red Health Bar
                        val hpPercent = (engine.hp / engine.maxHp).coerceIn(0f, 1f)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(Color(0xFF432936))
                                .border(0.5.dp, Color(0xFF111626), RoundedCornerShape(2.dp))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(hpPercent)
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(Color(0xFFED6468), Color(0xFFFF8A8F))
                                        )
                                    )
                            )
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        // Yellow XP Bar
                        val xpPercent = (engine.xp.toFloat() / engine.nextXp.toFloat()).coerceIn(0f, 1f)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(1.dp))
                                .background(Color(0xFF26324A))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(xpPercent)
                                    .background(Color(0xFFF0BD58))
                            )
                        }
                    }
                }

                // Resource Row (Gold, Keys, Souls)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(start = 2.dp)
                ) {
                    HudResourceItem(glyph = "🪙", value = "${engine.gold}", color = Color(0xFFF5C65A))
                    HudResourceItem(glyph = "🗝️", value = "${engine.keys}", color = Color(0xFFCAD5E7))
                    HudResourceItem(glyph = "⛏️", value = "${engine.souls}", color = Color(0xFFDCA3E8))
                }
            }

            // TOP-RIGHT: 3x3 Blessing Grid & Settings
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Settings Icon
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(30.dp)
                        .background(Color(0xFF17213C), RoundedCornerShape(6.dp))
                        .border(1.dp, BorderLight, RoundedCornerShape(6.dp))
                        .testTag("btn_hud_settings")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = TextWhite,
                        modifier = Modifier.size(16.dp)
                    )
                }

                // 3x3 Blessing Inventory Grid (9 Slots)
                Box(
                    modifier = Modifier
                        .background(Color(0xFF0E1730), RoundedCornerShape(8.dp))
                        .border(1.5.dp, Color(0xFF26324A), RoundedCornerShape(8.dp))
                        .padding(3.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        for (row in 0 until 3) {
                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                for (col in 0 until 3) {
                                    val index = row * 3 + col
                                    val blessing = engine.equippedBlessings.getOrNull(index)
                                    val fallbackGlyphs = listOf("✦", "↯", "◈", "✚", "◆", "☄", "◉", "✤", "⌁")

                                    Box(
                                        modifier = Modifier
                                            .size(22.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(
                                                if (blessing != null) blessing.rarity.color.copy(alpha = 0.35f)
                                                else Color(0xFF151E38)
                                            )
                                            .border(
                                                0.5.dp,
                                                if (blessing != null) blessing.rarity.color else Color(0xFF26324A),
                                                RoundedCornerShape(3.dp)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = blessing?.iconEmoji ?: fallbackGlyphs[index % fallbackGlyphs.size],
                                            fontSize = if (blessing != null) 11.sp else 8.sp,
                                            color = if (blessing != null) Color(0xFFF9F0DC) else Color(0xFF43516E),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // BOSS HEALTH BAR (shown if boss is present)
        if (boss != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .align(Alignment.TopCenter)
                    .padding(top = 64.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = boss.name.uppercase(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = Color(0xFFE9C8FF)
                )
                Spacer(modifier = Modifier.height(2.dp))
                val bossHpPercent = (boss.hp / boss.maxHp).coerceIn(0f, 1f)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color(0xFF2B163B))
                        .border(1.dp, Color(0xFFBF75F4), RoundedCornerShape(3.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(bossHpPercent)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFFBD6BE6), Color(0xFFFF8ABF))
                                )
                            )
                    )
                }
            }
        }

        // MID-LEFT STATS OVERLAY
        Column(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset(y = (-40).dp)
                .background(Color(0xBB10172A), RoundedCornerShape(6.dp))
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(6.dp))
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            StatRow("⚔️", "${engine.attack.toInt()}")
            StatRow("🛡️", "${engine.armor.toInt()}")
            StatRow("🎯", "${(engine.critChance * 100).toInt()}%")
            StatRow("👟", "${(1000f / engine.moveDelay * 10).toInt()}%")
        }

        // BOTTOM-RIGHT FLOOR INDICATOR
        val biomeName = when {
            engine.level % 3 == 0 -> "Boss Chamber"
            engine.level % 3 == 2 -> "Sanctuary Garden"
            else -> "Dungeon"
        }
        Text(
            text = "${engine.level} / ${engine.maxLevel} F $biomeName",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF8C91AA),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 150.dp)
        )
    }
}

@Composable
fun HudResourceItem(glyph: String, value: String, color: Color) {
    Row(
        modifier = Modifier
            .background(Color(0xFF17223A), RoundedCornerShape(4.dp))
            .padding(horizontal = 5.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(glyph, fontSize = 11.sp)
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = color
        )
    }
}

@Composable
fun StatRow(icon: String, value: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(icon, fontSize = 9.sp)
        Text(
            text = value,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFFEFF2E8)
        )
    }
}
