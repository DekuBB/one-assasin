package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "player_profile")
data class PlayerProfileEntity(
    @PrimaryKey val id: Int = 1,
    val selectedHeroId: String = "ZERO",
    val gold: Int = 300,
    val gems: Int = 50,
    val catalystStones: Int = 2,
    val totalRuns: Int = 0,
    val totalWins: Int = 0,
    val totalKills: Int = 0,
    val highestScore: Long = 0L,
    val karma: Int = 0
)

@Entity(tableName = "hero_progress")
data class HeroProgressEntity(
    @PrimaryKey val heroId: String,
    val isUnlocked: Boolean = false,
    val level: Int = 1,
    val starRank: Int = 1,
    val fragments: Int = 0,
    val equippedSkinId: String = "default"
)

@Entity(tableName = "user_equipment")
data class UserEquipmentEntity(
    @PrimaryKey val instanceId: String,
    val itemPresetId: String,
    val slot: String,
    val level: Int = 1,
    val isEquipped: Boolean = false
)

@Entity(tableName = "legacy_upgrades")
data class UserLegacyEntity(
    @PrimaryKey val upgradeId: String,
    val level: Int = 0
)

@Entity(tableName = "achievements")
data class UserAchievementEntity(
    @PrimaryKey val achievementId: String,
    val currentProgress: Int = 0,
    val isClaimed: Boolean = false
)

@Entity(tableName = "run_history")
data class RunHistoryEntity(
    @PrimaryKey(autoGenerate = true) val runId: Long = 0,
    val heroName: String,
    val durationSeconds: Long,
    val enemiesDefeated: Int,
    val bossesDefeated: Int,
    val totalDamageDealt: Long,
    val maxCombo: Int,
    val goldCollected: Int,
    val gemsCollected: Int,
    val blessingsCount: Int,
    val finalScore: Long,
    val isVictory: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface GameDao {
    @Query("SELECT * FROM player_profile WHERE id = 1")
    fun getProfileFlow(): Flow<PlayerProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProfile(profile: PlayerProfileEntity)

    @Query("SELECT * FROM hero_progress")
    fun getAllHeroProgressFlow(): Flow<List<HeroProgressEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveHeroProgress(progress: HeroProgressEntity)

    @Query("SELECT * FROM user_equipment")
    fun getAllEquipmentFlow(): Flow<List<UserEquipmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEquipment(items: List<UserEquipmentEntity>)

    @Query("DELETE FROM user_equipment WHERE instanceId = :instanceId")
    suspend fun deleteEquipment(instanceId: String)

    @Query("SELECT * FROM legacy_upgrades")
    fun getLegacyUpgradesFlow(): Flow<List<UserLegacyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLegacyUpgrade(legacy: UserLegacyEntity)

    @Query("SELECT * FROM achievements")
    fun getAchievementsFlow(): Flow<List<UserAchievementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAchievement(achievement: UserAchievementEntity)

    @Query("SELECT * FROM run_history ORDER BY timestamp DESC LIMIT 30")
    fun getRunHistoryFlow(): Flow<List<RunHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRun(run: RunHistoryEntity)
}

@Database(
    entities = [
        PlayerProfileEntity::class,
        HeroProgressEntity::class,
        UserEquipmentEntity::class,
        UserLegacyEntity::class,
        UserAchievementEntity::class,
        RunHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AssasinDatabase : RoomDatabase() {
    abstract fun gameDao(): GameDao
}
