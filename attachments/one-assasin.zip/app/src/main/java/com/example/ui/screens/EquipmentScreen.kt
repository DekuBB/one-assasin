package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.UserEquipmentEntity
import com.example.data.model.EquipSlot
import com.example.data.model.EquipmentCatalog
import com.example.data.model.EquipmentItem
import com.example.ui.AppNavState
import com.example.ui.GameViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EquipmentScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf(0) } // 0: Equipped & Inventory, 1: 3-to-1 Merge Forge

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("BLACKSMITH FORGE", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(AppNavState.HUB_WORLD) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianDark)
            )
        },
        containerColor = VoidBlack
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = ObsidianDark,
                contentColor = TextWhite
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("GEAR & INVENTORY") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("3-TO-1 MERGE FORGE") }
                )
            }

            if (selectedTab == 0) {
                GearAndInventoryTab(viewModel = viewModel, uiState = uiState)
            } else {
                MergeForgeTab(viewModel = viewModel, uiState = uiState)
            }
        }
    }
}

@Composable
fun GearAndInventoryTab(
    viewModel: GameViewModel,
    uiState: com.example.ui.GameUiState
) {
    val equipped = uiState.equipmentList.filter { it.isEquipped }
    val inventory = uiState.equipmentList

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "EQUIPPED SLOTS (8 SLOTS)",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = NeonCyan
            )
        }

        item {
            // 8 Equipped Slots Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(EquipSlot.values()) { slot ->
                    val equipEntity = equipped.find { it.slot == slot.name }
                    val preset = equipEntity?.let { e -> EquipmentCatalog.ALL_PRESETS.find { it.id == e.itemPresetId } }

                    Box(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(DungeonSlate)
                            .border(1.5.dp, preset?.rarity?.color ?: DungeonBorder, RoundedCornerShape(10.dp))
                            .padding(6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (preset != null) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(preset.iconEmoji, fontSize = 20.sp)
                                Text(slot.label, fontSize = 9.sp, color = TextMuted)
                                Text("Lv.${equipEntity.level}", fontSize = 9.sp, color = GoldSun, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(slot.iconEmoji, fontSize = 16.sp)
                                Text(slot.label, fontSize = 9.sp, color = TextMuted)
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "ALL EQUIPMENT INVENTORY (${inventory.size} ITEMS)",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = GoldSun
            )
        }

        items(inventory) { userEq ->
            val preset = EquipmentCatalog.ALL_PRESETS.find { it.id == userEq.itemPresetId }
            if (preset != null) {
                EquipmentItemRow(
                    userItem = userEq,
                    preset = preset,
                    gold = uiState.profile.gold,
                    stones = uiState.profile.catalystStones,
                    onEquip = { viewModel.equipItem(userEq.instanceId) },
                    onUpgrade = { viewModel.upgradeEquipment(userEq.instanceId) }
                )
            }
        }
    }
}

@Composable
fun EquipmentItemRow(
    userItem: UserEquipmentEntity,
    preset: EquipmentItem,
    gold: Int,
    stones: Int,
    onEquip: () -> Unit,
    onUpgrade: () -> Unit
) {
    val upGoldCost = userItem.level * 80 + 50
    val upStonesCost = (userItem.level / 5) + 1
    val canUpgrade = gold >= upGoldCost && stones >= upStonesCost

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DungeonSlate),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(preset.rarity.color, DungeonBorder)))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0x33000000))
                    .border(1.dp, preset.rarity.color, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(preset.iconEmoji, fontSize = 24.sp)
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = preset.name,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Text(
                        text = "+${userItem.level}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldSun
                    )
                }
                Text(
                    text = "${preset.rarity.label} ${preset.slot.label} • ${preset.specialPerk}",
                    fontSize = 11.sp,
                    color = preset.rarity.color
                )
            }

            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (!userItem.isEquipped) {
                    Button(
                        onClick = onEquip,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("EQUIP", fontSize = 10.sp, color = ObsidianDark, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Badge(containerColor = EmeraldGreen) {
                        Text("EQUIPPED", color = ObsidianDark, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(2.dp))
                    }
                }

                Button(
                    onClick = onUpgrade,
                    enabled = canUpgrade,
                    colors = ButtonDefaults.buttonColors(containerColor = DungeonBorder),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text("UP ($upGoldCost🪙)", fontSize = 9.sp, color = TextWhite)
                }
            }
        }
    }
}

@Composable
fun MergeForgeTab(
    viewModel: GameViewModel,
    uiState: com.example.ui.GameUiState
) {
    // Group equipment by preset or slot to allow 3-to-1 merge
    val itemsBySlot = uiState.equipmentList.groupBy { it.slot }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = ObsidianDark),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.verticalGradient(listOf(FlameOrange, VoidAmethyst)))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("🔥 3-TO-1 FORGE MERGE 🔥", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = GoldSun)
                    Text(
                        "Combine 3 items of the same slot to synthesize a higher rarity artifact!",
                        fontSize = 12.sp,
                        color = TextMuted,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }

        items(EquipSlot.values()) { slot ->
            val slotItems = itemsBySlot[slot.name] ?: emptyList()
            val canMerge = slotItems.size >= 3

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DungeonSlate)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("${slot.label} Category", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        Text("${slotItems.size} items available", fontSize = 11.sp, color = TextMuted)
                    }

                    Button(
                        onClick = { viewModel.mergeEquipment(slotItems) },
                        enabled = canMerge,
                        colors = ButtonDefaults.buttonColors(containerColor = if (canMerge) FlameOrange else DungeonBorder),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(if (canMerge) "MERGE 3 ITEMS ⚒️" else "NEED 3 ITEMS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
