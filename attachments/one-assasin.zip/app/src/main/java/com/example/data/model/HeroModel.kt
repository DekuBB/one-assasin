package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class HeroId {
    NYRA,
    TOR,
    LUMA,
    BELPA,
    ZERO,
    LYRA
}

enum class SkillId {
    SHADOW_LEAP,
    BLADE_BLOSSOM,
    SHIELD_BASH,
    RUNE_WAVE,
    STAR_BEAM,
    ASTRAL_PULSE,
    SUN_STRIKE,
    SOLAR_BURST,
    VOID_SLASH,
    SHADOW_STEP
}

data class HeroSkill(
    val id: SkillId,
    val name: String,
    val description: String,
    val cooldownMs: Long,
    val damageMultiplier: Float = 1.5f,
    val iconEmoji: String = "⚔️",
    val shortcutKey: String = "Q"
)

data class HeroDefinition(
    val id: HeroId,
    val name: String,
    val role: String,
    val title: String,
    val description: String,
    val iconEmoji: String,
    val primaryColor: Color,
    val accentColor: Color,
    val glowColor: Color,
    val avatarEmoji: String,
    val baseHp: Float,
    val baseAttack: Float,
    val baseDefense: Float,
    val moveDelayMs: Long, // Lower = faster
    val baseCritChance: Float,
    val baseCritDamage: Float = 1.85f,
    val skill1: HeroSkill,
    val skill2: HeroSkill,
    val passiveName: String,
    val passiveDescription: String,
    val unlockGoldCost: Int = 0,
    val unlockGemsCost: Int = 0
)

object HeroCatalog {
    val NYRA = HeroDefinition(
        id = HeroId.NYRA,
        name = "Nyra",
        role = "Cień sztyletu",
        title = "Shadow Blade",
        description = "Szybka zabójczyni, zadaje olbrzymie obrażenia krytyczne i przeskakuje przez wrogów.",
        iconEmoji = "◆",
        primaryColor = Color(0xFFE971A8),
        accentColor = Color(0xFFFF8ABF),
        glowColor = Color(0xFFFFBEDB),
        avatarEmoji = "🗡️",
        baseHp = 92f,
        baseAttack = 19f,
        baseDefense = 4f,
        moveDelayMs = 155L,
        baseCritChance = 0.23f,
        baseCritDamage = 1.85f,
        skill1 = HeroSkill(
            id = SkillId.SHADOW_LEAP,
            name = "Skok cienia",
            description = "Przeskakuje o 2 kafelki naprzód, tnąc każdego wroga na drodze za 150% obrażeń krytycznych.",
            cooldownMs = 4000L,
            damageMultiplier = 1.5f,
            iconEmoji = "⚡",
            shortcutKey = "Q"
        ),
        skill2 = HeroSkill(
            id = SkillId.BLADE_BLOSSOM,
            name = "Kwiat ostrzy",
            description = "Wypuszcza wir zabójczych sztyletów we wszystkie strony, raniąc wrogów do 2 pól.",
            cooldownMs = 8500L,
            damageMultiplier = 1.25f,
            iconEmoji = "🌸",
            shortcutKey = "E"
        ),
        passiveName = "Instynkt Cienia",
        passiveDescription = "10% szansy na wyzwolenie Supernovej przy każdym kroku.",
        unlockGoldCost = 0,
        unlockGemsCost = 0
    )

    val TOR = HeroDefinition(
        id = HeroId.TOR,
        name = "Tor",
        role = "Strażnik run",
        title = "Rune Guardian",
        description = "Wytrzymały wojownik z runiczną tarczą, odpiera hordy z bliska i regeneruje zdrowie.",
        iconEmoji = "✦",
        primaryColor = Color(0xFF75B8EE),
        accentColor = Color(0xFF4A90E2),
        glowColor = Color(0xFFBDE5FF),
        avatarEmoji = "🛡️",
        baseHp = 142f,
        baseAttack = 14f,
        baseDefense = 10f,
        moveDelayMs = 190L,
        baseCritChance = 0.10f,
        baseCritDamage = 1.6f,
        skill1 = HeroSkill(
            id = SkillId.SHIELD_BASH,
            name = "Uderzenie tarczą",
            description = "Potężny cios tarczą rani wszystkich wrogów w zasięgu 1 kafelka i ogłusza ich.",
            cooldownMs = 4000L,
            damageMultiplier = 1.45f,
            iconEmoji = "🛡️",
            shortcutKey = "Q"
        ),
        skill2 = HeroSkill(
            id = SkillId.RUNE_WAVE,
            name = "Runiczna fala",
            description = "Uwalnia falę energii leczącą +8 HP i zadającą obrażenia wrogom wokół.",
            cooldownMs = 8500L,
            damageMultiplier = 1.1f,
            iconEmoji = "🌊",
            shortcutKey = "E"
        ),
        passiveName = "Pancerz Run",
        passiveDescription = "Stałe -1 obrażeń od każdego uderzenia i większa obrona.",
        unlockGoldCost = 600,
        unlockGemsCost = 30
    )

    val LUMA = HeroDefinition(
        id = HeroId.LUMA,
        name = "Luma",
        role = "Łowczyni iskier",
        title = "Spark Huntress",
        description = "Kontroluje dystans, przebija szeregi wrogów promieniem gwiazd i sieje zniszczenie.",
        iconEmoji = "✹",
        primaryColor = Color(0xFFB785FA),
        accentColor = Color(0xFF9D4EDD),
        glowColor = Color(0xFFE2CBFF),
        avatarEmoji = "✨",
        baseHp = 104f,
        baseAttack = 16f,
        baseDefense = 6f,
        moveDelayMs = 175L,
        baseCritChance = 0.16f,
        baseCritDamage = 1.75f,
        skill1 = HeroSkill(
            id = SkillId.STAR_BEAM,
            name = "Promień gwiazd",
            description = "Wystrzeliwuje 5-kafelkowy promień światła przebijający wszystkich potworów w linii.",
            cooldownMs = 4000L,
            damageMultiplier = 1.55f,
            iconEmoji = "☄️",
            shortcutKey = "Q"
        ),
        skill2 = HeroSkill(
            id = SkillId.ASTRAL_PULSE,
            name = "Puls astralny",
            description = "Wysyła potężny impuls energii na odległość 4 kafelków, raniąc wszystkich wrogów i lecząc +3 HP.",
            cooldownMs = 8500L,
            damageMultiplier = 1.25f,
            iconEmoji = "🌌",
            shortcutKey = "E"
        ),
        passiveName = "Gwiezdny Pył",
        passiveDescription = "14% szansy na wyzwolenie Supernovej przy ruchu.",
        unlockGoldCost = 1200,
        unlockGemsCost = 50
    )

    val BELPA = HeroDefinition(
        id = HeroId.BELPA,
        name = "Belpa",
        role = "Wojowniczka słońca",
        title = "Sun Blade",
        description = "Mistrzyni ognistych mieczy, zadaje obszarowe obrażenia od ognia i spala hordy.",
        iconEmoji = "☀️",
        primaryColor = Color(0xFFF6BD60),
        accentColor = Color(0xFFE07A5F),
        glowColor = Color(0xFFFFE0A0),
        avatarEmoji = "🔥",
        baseHp = 118f,
        baseAttack = 18f,
        baseDefense = 8f,
        moveDelayMs = 165L,
        baseCritChance = 0.15f,
        baseCritDamage = 1.8f,
        skill1 = HeroSkill(
            id = SkillId.SUN_STRIKE,
            name = "Słoneczne cięcie",
            description = "Uderza z góry snopem ognia, który podpala potwory w promieniu 2 pól.",
            cooldownMs = 4200L,
            damageMultiplier = 1.6f,
            iconEmoji = "☀️",
            shortcutKey = "Q"
        ),
        skill2 = HeroSkill(
            id = SkillId.SOLAR_BURST,
            name = "Erupcja plazmy",
            description = "Eksploduje energią słoneczną, odrzucając wrogów i przywracając wigor.",
            cooldownMs = 8000L,
            damageMultiplier = 1.35f,
            iconEmoji = "💥",
            shortcutKey = "E"
        ),
        passiveName = "Płomienny Krok",
        passiveDescription = "Zostawia ślad ognia raniący wrogów wchodzących na zajmowany kafelek.",
        unlockGoldCost = 2000,
        unlockGemsCost = 80
    )

    val ALL = listOf(NYRA, TOR, LUMA, BELPA)

    fun getHero(id: HeroId): HeroDefinition {
        return ALL.find { it.id == id } ?: NYRA
    }
}
