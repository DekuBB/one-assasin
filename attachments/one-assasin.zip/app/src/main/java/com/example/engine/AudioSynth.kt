package com.example.engine

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class AudioSynth {
    private val scope = CoroutineScope(Dispatchers.Default)
    private val sampleRate = 22050
    var isMuted = false

    private fun playPcm(samples: ShortArray) {
        if (isMuted) return
        scope.launch {
            try {
                val bufferSize = samples.size * 2
                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(samples, 0, samples.size)
                audioTrack.play()
                Thread.sleep((samples.size * 1000L / sampleRate) + 50L)
                audioTrack.stop()
                audioTrack.release()
            } catch (_: Exception) {
            }
        }
    }

    fun playSlash() {
        val numSamples = (sampleRate * 0.12).toInt()
        val samples = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val freq = 550.0 - (t / 0.12) * 350.0
            val envelope = exp(-t * 22.0)
            val noise = (Math.random() * 2.0 - 1.0) * 0.4
            val tone = sin(2 * PI * freq * t) * 0.6
            val value = ((tone + noise) * envelope * Short.MAX_VALUE * 0.7).toInt()
            samples[i] = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
    }

    fun playSlashSound() = playSlash()

    fun playHit() {
        val numSamples = (sampleRate * 0.08).toInt()
        val samples = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val noise = (Math.random() * 2.0 - 1.0) * 0.9
            val envelope = exp(-t * 40.0)
            val value = (noise * envelope * Short.MAX_VALUE * 0.6).toInt()
            samples[i] = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
    }

    fun playHitSound() = playHit()

    fun playDash() {
        val numSamples = (sampleRate * 0.15).toInt()
        val samples = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val freq = 200.0 + (t / 0.15) * 600.0
            val envelope = sin(PI * (t / 0.15))
            val noise = (Math.random() * 2.0 - 1.0) * 0.7
            val tone = sin(2 * PI * freq * t) * 0.3
            val value = ((tone + noise) * envelope * Short.MAX_VALUE * 0.5).toInt()
            samples[i] = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
    }

    fun playDashSound() = playDash()

    fun playPickup() {
        val numSamples = (sampleRate * 0.18).toInt()
        val samples = ShortArray(numSamples)
        val note1Samples = (sampleRate * 0.09).toInt()
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val freq = if (i < note1Samples) 587.33 else 880.0
            val envelope = exp(-((i % note1Samples).toDouble() / sampleRate) * 15.0)
            val tone = sin(2 * PI * freq * t)
            val value = (tone * envelope * Short.MAX_VALUE * 0.6).toInt()
            samples[i] = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
    }

    fun playChestOpenSound() = playPickup()

    fun playKillSound() {
        val numSamples = (sampleRate * 0.16).toInt()
        val samples = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val freq = 300.0 + (t / 0.16) * 400.0
            val envelope = exp(-t * 14.0)
            val tone = sin(2 * PI * freq * t)
            val value = (tone * envelope * Short.MAX_VALUE * 0.7).toInt()
            samples[i] = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
    }

    fun playLevelUpSound() {
        val numSamples = (sampleRate * 0.35).toInt()
        val samples = ShortArray(numSamples)
        val step = numSamples / 3
        val notes = doubleArrayOf(440.0, 554.37, 659.25)
        for (i in 0 until numSamples) {
            val noteIndex = (i / step).coerceIn(0, 2)
            val freq = notes[noteIndex]
            val t = i.toDouble() / sampleRate
            val localT = (i % step).toDouble() / sampleRate
            val envelope = exp(-localT * 8.0)
            val tone = sin(2 * PI * freq * t)
            val value = (tone * envelope * Short.MAX_VALUE * 0.7).toInt()
            samples[i] = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
    }

    fun playEnergyBeamSound() {
        val numSamples = (sampleRate * 0.22).toInt()
        val samples = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val freq = 700.0 + sin(t * 80.0) * 200.0
            val envelope = exp(-t * 9.0)
            val tone = sin(2 * PI * freq * t)
            val value = (tone * envelope * Short.MAX_VALUE * 0.7).toInt()
            samples[i] = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
    }

    fun playTeleportSound() {
        val numSamples = (sampleRate * 0.20).toInt()
        val samples = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val freq = 200.0 + (t / 0.20) * 800.0
            val envelope = exp(-t * 6.0)
            val tone = sin(2 * PI * freq * t)
            val value = (tone * envelope * Short.MAX_VALUE * 0.6).toInt()
            samples[i] = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
    }

    fun playDefeatSound() {
        val numSamples = (sampleRate * 0.40).toInt()
        val samples = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val freq = 300.0 - (t / 0.40) * 200.0
            val envelope = exp(-t * 5.0)
            val tone = sin(2 * PI * freq * t)
            val value = (tone * envelope * Short.MAX_VALUE * 0.7).toInt()
            samples[i] = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
    }

    fun playVictory() {
        val numSamples = (sampleRate * 0.6).toInt()
        val samples = ShortArray(numSamples)
        val step = numSamples / 3
        val notes = doubleArrayOf(523.25, 659.25, 783.99)
        for (i in 0 until numSamples) {
            val noteIndex = (i / step).coerceIn(0, 2)
            val freq = notes[noteIndex]
            val t = i.toDouble() / sampleRate
            val localT = (i % step).toDouble() / sampleRate
            val envelope = exp(-localT * 6.0)
            val tone = sin(2 * PI * freq * t)
            val value = (tone * envelope * Short.MAX_VALUE * 0.7).toInt()
            samples[i] = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
    }

    fun playVictorySound() = playVictory()
}
