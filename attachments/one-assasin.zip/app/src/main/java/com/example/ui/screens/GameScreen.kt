package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Blessing
import com.example.engine.GameEngine
import com.example.engine.GameScreenState
import com.example.ui.AppNavState
import com.example.ui.GameViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun GameScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val engine = viewModel.activeEngine ?: return
    val textMeasurer = rememberTextMeasurer()

    var showSettingsDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0D1325))
    ) {
        // 1. Pixel Arena Canvas (9x11 grid, stone tiles, fog of war, enemies, hero, lighting)
        PixelArenaCanvas(
            engine = engine,
            textMeasurer = textMeasurer,
            screenShakeEnabled = uiState.screenShakeEnabled,
            modifier = Modifier.fillMaxSize()
        )

        // 2. Top HUD (Health, XP, Karma, Resources, 3x3 Blessing Grid, Stats)
        GameHud(
            engine = engine,
            onOpenSettings = { showSettingsDialog = true },
            modifier = Modifier.align(Alignment.TopCenter)
        )

        // 3. Virtual Controls (Bottom D-pad and Skill buttons)
        VirtualControls(
            engine = engine,
            modifier = Modifier.align(Alignment.BottomCenter)
        )

        // 4. Overlays & Dialogs based on Game Engine State
        when (engine.state) {
            GameScreenState.BLESSING_UPGRADE_CHOICE -> {
                BlessingChoiceOverlay(
                    choices = engine.upgradeChoices,
                    onSelect = { blessing -> engine.chooseBlessing(blessing) }
                )
            }
            GameScreenState.ARCHMAGE_KARMA_ALTAR -> {
                ArchmageKarmaOverlay(
                    karma = engine.karma,
                    onClose = { engine.state = GameScreenState.PLAYING }
                )
            }
            GameScreenState.VICTORY -> {
                RunResultOverlay(
                    isVictory = true,
                    level = engine.level,
                    kills = engine.kills,
                    souls = engine.souls,
                    gold = engine.gold,
                    onRestart = { viewModel.startNewRun(engine.hero.id) },
                    onReturnToMenu = { viewModel.onEndRunReturnToHub() }
                )
            }
            GameScreenState.DEFEAT -> {
                RunResultOverlay(
                    isVictory = false,
                    level = engine.level,
                    kills = engine.kills,
                    souls = engine.souls,
                    gold = engine.gold,
                    onRestart = { viewModel.startNewRun(engine.hero.id) },
                    onReturnToMenu = { viewModel.onEndRunReturnToHub() }
                )
            }
            else -> {}
        }

        // Settings Dialog
        if (showSettingsDialog) {
            InGameSettingsDialog(
                viewModel = viewModel,
                onDismiss = { showSettingsDialog = false },
                onAbandonRun = {
                    showSettingsDialog = false
                    viewModel.onEndRunReturnToHub()
                }
            )
        }
    }
}

@Composable
fun BlessingChoiceOverlay(
    choices: List<Blessing>,
    onSelect: (Blessing) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xD9050913))
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .testTag("dialog_blessing_choice"),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF151E38)),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.verticalGradient(listOf(Color(0xFF6E79A8), Color(0xFF26324A)))
            )
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "POZIOM BOHATERA W GÓRĘ",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp,
                    color = Color(0xFF83E9E0)
                )

                Text(
                    text = "Wybierz błogosławieństwo",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    choices.forEach { blessing ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(blessing) }
                                .testTag("btn_blessing_${blessing.id}"),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C2747)),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.horizontalGradient(
                                    listOf(blessing.rarity.color, Color(0xFF46527A))
                                )
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(blessing.rarity.color.copy(alpha = 0.25f))
                                        .border(1.dp, blessing.rarity.color, RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = blessing.iconEmoji, fontSize = 20.sp)
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = blessing.name,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFFFCF78)
                                        )
                                        Text(
                                            text = "[${blessing.rarity.label}]",
                                            fontSize = 10.sp,
                                            color = blessing.rarity.color
                                        )
                                    }
                                    Text(
                                        text = blessing.description,
                                        fontSize = 11.sp,
                                        color = Color(0xFFB7C3DF),
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ArchmageKarmaOverlay(
    karma: Int,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xE6050913))
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(0.92f),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF13172C)),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.verticalGradient(listOf(Color(0xFF00F2FE), Color(0xFF9D4EDD)))
            )
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Archmage Hazel",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF8EE7E2)
                )

                Text(
                    text = "\"Every choice leaves a trace. Choose your reward. It is a reflection of your Karma.\"",
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    color = TextMuted
                )

                Text(
                    text = "कर्म Karma: $karma",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFFFF9D78)
                )

                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF26324D)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("KONTYNUUJ", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun RunResultOverlay(
    isVictory: Boolean,
    level: Int,
    kills: Int,
    souls: Int,
    gold: Int,
    onRestart: () -> Unit,
    onReturnToMenu: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xEE050913))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .testTag("dialog_run_result"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isVictory) Color(0xFF1B233D) else Color(0xFF30223D)
            ),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.verticalGradient(
                    if (isVictory) listOf(Color(0xFFF6BD60), Color(0xFF8EE7E2))
                    else listOf(Color(0xFFCF4D50), Color(0xFF653842))
                )
            )
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = if (isVictory) "PAŁAC OCALONY" else "WYPRAWA ZAKOŃCZONA",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp,
                    color = if (isVictory) Color(0xFFF6BD60) else Color(0xFFFF8C83)
                )

                Text(
                    text = if (isVictory) "Korona odzyskana" else "Cień pochłonął bohatera",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    color = TextWhite
                )

                Text(
                    text = "Dotarłeś do poziomu $level, pokonałeś $kills wrogów i zdobyłeś $souls dusz oraz $gold złota.",
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    color = Color(0xFFC0C9E6),
                    lineHeight = 16.sp
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onRestart,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFF6BD60),
                            contentColor = Color(0xFF25141C)
                        ),
                        shape = RoundedCornerShape(11.dp),
                        modifier = Modifier.fillMaxWidth().testTag("btn_restart_run")
                    ) {
                        Text("Spróbuj ponownie", fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }

                    OutlinedButton(
                        onClick = onReturnToMenu,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDCE7FF)),
                        shape = RoundedCornerShape(11.dp),
                        modifier = Modifier.fillMaxWidth().testTag("btn_menu_return")
                    ) {
                        Text("Wybór bohatera", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun InGameSettingsDialog(
    viewModel: GameViewModel,
    onDismiss: () -> Unit,
    onAbandonRun: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("PAUZA / USTAWIENIA", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Dźwięki i syntezator", fontSize = 13.sp)
                    Switch(checked = uiState.soundEnabled, onCheckedChange = { viewModel.toggleSound() })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Wibracje haptyczne", fontSize = 13.sp)
                    Switch(checked = uiState.hapticsEnabled, onCheckedChange = { viewModel.toggleHaptics() })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Wstrząsy ekranu", fontSize = 13.sp)
                    Switch(checked = uiState.screenShakeEnabled, onCheckedChange = { viewModel.toggleScreenShake() })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("WZNÓW GRĘ", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onAbandonRun) {
                Text("ZAKOŃCZ WYPRAWĘ", color = CrimsonBlade)
            }
        },
        containerColor = ObsidianDark
    )
}
