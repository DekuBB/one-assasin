package com.example.data.model

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class EnemyType(
    val displayName: String,
    val isBoss: Boolean = false,
    val isMiniboss: Boolean = false,
    val emoji: String,
    val baseHp: Float,
    val baseAttack: Float,
    val baseSpeed: Float,
    val attackRange: Float,
    val attackCooldownMs: Long,
    val telegraphDurationMs: Long,
    val primaryColor: Color
) {
    GOBLIN("Goblin Stalker", false, false, "👺", 65f, 12f, 140f, 48f, 1600L, 700L, EmeraldGreen),
    SKELETON("Bone Archer", false, false, "💀", 50f, 16f, 110f, 220f, 2200L, 900L, RarityCommon),
    VOID_BAT("Void Skitterer", false, false, "🦇", 38f, 10f, 200f, 40f, 1200L, 500L, VoidAmethyst),
    BLOOD_CULTIST("Blood Cultist", false, false, "🧙", 95f, 18f, 95f, 180f, 2400L, 1000L, BloodDark),
    IRON_SPIDER("Automaton Spider", false, false, "🕷️", 130f, 22f, 120f, 55f, 1800L, 800L, FlameOrange),
    
    // Elite Variants (scaled in runtime)
    ELITE_BERSERKER("Elite Berserker", false, true, "👹", 350f, 28f, 160f, 60f, 1500L, 650L, CrimsonBlade),
    
    // Miniboss
    BLOOD_KNIGHT("Blood Knight", false, true, "🩸⚔️", 900f, 32f, 130f, 75f, 2000L, 900L, CrimsonBlade),
    
    // Final Bosses
    GATEKEEPER("The Gatekeeper", true, false, "👑💀", 4000f, 42f, 115f, 90f, 1800L, 800L, VoidPurple),
    IRON_WIDOW("The Iron Widow", true, false, "🕷️⚡", 5000f, 45f, 140f, 110f, 1600L, 750L, FlameOrange)
}

enum class EnemyState {
    IDLE,
    CHASING,
    TELEGRAPHING,
    ATTACKING,
    HURT,
    DYING
}

data class EnemyEntity(
    val id: Long,
    val type: EnemyType,
    var position: Offset,
    var targetPosition: Offset = Offset.Zero,
    var hp: Float,
    val maxHp: Float,
    val attack: Float,
    val speed: Float,
    var state: EnemyState = EnemyState.CHASING,
    var stateTimerMs: Long = 0L,
    var attackCooldownTimerMs: Long = 0L,
    var telegraphRadius: Float = 0f,
    var telegraphAngle: Float = 0f,
    var telegraphIsCone: Boolean = false,
    var isFacingRight: Boolean = true,
    var bossPhase: Int = 1,
    var isEnraged: Boolean = false,
    var poisonTicksRemaining: Int = 0,
    var chillTicksRemaining: Int = 0,
    val isElite: Boolean = false
) {
    val hpRatio: Float get() = (hp / maxHp).coerceIn(0f, 1f)
}
