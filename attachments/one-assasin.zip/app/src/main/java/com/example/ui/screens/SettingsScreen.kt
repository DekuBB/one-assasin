package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppNavState
import com.example.ui.GameViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "SETTINGS & SYSTEM",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        letterSpacing = 1.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(AppNavState.MAIN_MENU) },
                        modifier = Modifier.testTag("btn_settings_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextWhite
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianDark,
                    titleContentColor = TextWhite
                )
            )
        },
        containerColor = VoidBlack
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Audio & Feedback Section
            SettingsSectionHeader(title = "AUDIO & FEEDBACK")

            SettingsToggleCard(
                title = "8-Bit Sound Synthesizer",
                subtitle = "Combat slashes, spells, pickups & retro SFX",
                icon = "🔊",
                checked = uiState.soundEnabled,
                onCheckedChange = { viewModel.toggleSound() },
                accentColor = CyanGlow
            )

            SettingsToggleCard(
                title = "Haptic Vibration",
                subtitle = "Physical impact vibration on hit & dashes",
                icon = "📳",
                checked = uiState.hapticsEnabled,
                onCheckedChange = { viewModel.toggleHaptics() },
                accentColor = FlameOrange
            )

            SettingsToggleCard(
                title = "Screen Shake Impact",
                subtitle = "Visceral camera trauma on critical blows",
                icon = "⚡",
                checked = uiState.screenShakeEnabled,
                onCheckedChange = { viewModel.toggleScreenShake() },
                accentColor = CrimsonBlade
            )

            // Gameplay & Controls Section
            SettingsSectionHeader(title = "CONTROLS & ACCESSIBILITY")

            SettingsToggleCard(
                title = "Left-Handed Mode",
                subtitle = "Swaps joystick to right, action buttons to left",
                icon = "🖐️",
                checked = uiState.isLeftHanded,
                onCheckedChange = { viewModel.toggleLeftHanded() },
                accentColor = VoidAmethyst
            )

            SettingsToggleCard(
                title = "Smart Auto-Aim Assistant",
                subtitle = "Prioritizes closest elite & boss targets",
                icon = "🎯",
                checked = uiState.autoAimEnabled,
                onCheckedChange = { viewModel.toggleAutoAim() },
                accentColor = EmeraldGreen
            )

            // Game Version & Credits
            SettingsSectionHeader(title = "SYSTEM INFO")

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = ObsidianDark),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(BorderLight, Color.Transparent)))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "ONE ASSASIN",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldSun
                    )
                    Text(
                        text = "Version 1.0.0 — Roguelike Action Engine",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                    Text(
                        text = "Real-Time Combat • Procedural Abyss • 100+ Synergies",
                        fontSize = 11.sp,
                        color = NeonCyan
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace,
        letterSpacing = 1.5.sp,
        color = TextMuted,
        modifier = Modifier.padding(start = 4.dp)
    )
}

@Composable
fun SettingsToggleCard(
    title: String,
    subtitle: String,
    icon: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    accentColor: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DungeonSlate),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(
                if (checked) listOf(accentColor.copy(alpha = 0.5f), Color.Transparent)
                else listOf(BorderLight, Color.Transparent)
            )
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(text = icon, fontSize = 22.sp)

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = TextWhite,
                    checkedTrackColor = accentColor,
                    uncheckedThumbColor = TextMuted,
                    uncheckedTrackColor = Zinc900
                )
            )
        }
    }
}
