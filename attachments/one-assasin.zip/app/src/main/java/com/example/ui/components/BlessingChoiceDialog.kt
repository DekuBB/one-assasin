package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Blessing
import com.example.ui.theme.*

@Composable
fun BlessingChoiceDialog(
    choices: List<Blessing>,
    onSelect: (Blessing) -> Unit
) {
    Dialog(onDismissRequest = { /* Must choose */ }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = ObsidianDark),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.verticalGradient(listOf(VoidAmethyst, CrimsonBlade)))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "✨ CHOOSE A BLESSING ✨",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = GoldSun,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Acquire ancient power to augment your blade and spirit.",
                    fontSize = 12.sp,
                    color = TextMuted,
                    textAlign = TextAlign.Center
                )

                choices.forEachIndexed { index, blessing ->
                    BlessingCard(
                        blessing = blessing,
                        index = index,
                        onClick = { onSelect(blessing) }
                    )
                }
            }
        }
    }
}

@Composable
fun BlessingCard(
    blessing: Blessing,
    index: Int,
    onClick: () -> Unit
) {
    val rarityColor = blessing.rarity.color

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DungeonSlate)
            .border(1.5.dp, rarityColor.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag("blessing_card_$index")
            .padding(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Icon
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0x33000000))
                    .border(1.dp, rarityColor, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = blessing.iconEmoji, fontSize = 24.sp)
            }

            // Info
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = blessing.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Text(
                        text = blessing.rarity.label.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = rarityColor
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = blessing.description,
                    fontSize = 12.sp,
                    color = TextMuted,
                    lineHeight = 15.sp
                )
            }
        }
    }
}
