package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val ImmersiveDarkColorScheme = darkColorScheme(
    primary = CrimsonBlade,
    onPrimary = TextWhite,
    primaryContainer = BloodDark,
    onPrimaryContainer = TextWhite,
    secondary = CyanGlow,
    onSecondary = VoidBlack,
    secondaryContainer = CyanDark,
    onSecondaryContainer = NeonCyan,
    tertiary = GoldSun,
    onTertiary = VoidBlack,
    background = VoidBlack,
    onBackground = TextWhite,
    surface = ObsidianDark,
    onSurface = TextWhite,
    surfaceVariant = DungeonSlate,
    onSurfaceVariant = TextMuted,
    outline = DungeonBorder,
    outlineVariant = BorderSubtle
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ImmersiveDarkColorScheme,
        typography = Typography,
        content = content
    )
}
