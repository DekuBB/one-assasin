package com.example.ui

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.data.model.*
import com.example.engine.AudioSynth
import com.example.engine.GameEngine
import com.example.engine.GameScreenState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class AppNavState {
    MAIN_MENU,
    HUB_WORLD,
    HERO_SELECT,
    EQUIPMENT_FORGE,
    BLESSING_CODEX,
    LEGACY_ALTAR,
    BOUNTY_ACHIEVEMENTS,
    SETTINGS,
    IN_GAME
}

data class GameUiState(
    val navState: AppNavState = AppNavState.MAIN_MENU,
    val profile: PlayerProfileEntity = PlayerProfileEntity(),
    val heroesProgress: List<HeroProgressEntity> = emptyList(),
    val equipmentList: List<UserEquipmentEntity> = emptyList(),
    val legacyList: List<UserLegacyEntity> = emptyList(),
    val achievementsList: List<UserAchievementEntity> = emptyList(),
    val runHistory: List<RunHistoryEntity> = emptyList(),
    val selectedHeroId: HeroId = HeroId.ZERO,
    
    // Settings
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val screenShakeEnabled: Boolean = true,
    val autoAimEnabled: Boolean = true,
    val isLeftHanded: Boolean = false,
    
    // In-game dynamic state tick
    val engineStateVersion: Long = 0L,
    val lastRunSummary: RunSummary? = null
)

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = GameRepository(application)
    val audioSynth = AudioSynth()
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = application.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    var activeEngine: GameEngine? = null
        private set

    private var gameLoopJob: Job? = null

    init {
        viewModelScope.launch {
            combine(
                repository.playerProfile,
                repository.heroProgress,
                repository.equipmentList,
                repository.legacyUpgrades,
                repository.achievements,
                repository.runHistory
            ) { flows: Array<Any> ->
                @Suppress("UNCHECKED_CAST")
                val profile = flows[0] as PlayerProfileEntity
                @Suppress("UNCHECKED_CAST")
                val heroes = flows[1] as List<HeroProgressEntity>
                @Suppress("UNCHECKED_CAST")
                val equip = flows[2] as List<UserEquipmentEntity>
                @Suppress("UNCHECKED_CAST")
                val legacy = flows[3] as List<UserLegacyEntity>
                @Suppress("UNCHECKED_CAST")
                val ach = flows[4] as List<UserAchievementEntity>
                @Suppress("UNCHECKED_CAST")
                val history = flows[5] as List<RunHistoryEntity>

                val heroEnum = try {
                    HeroId.valueOf(profile.selectedHeroId)
                } catch (_: Exception) {
                    HeroId.ZERO
                }
                _uiState.value.copy(
                    profile = profile,
                    heroesProgress = heroes,
                    equipmentList = equip,
                    legacyList = legacy,
                    achievementsList = ach,
                    runHistory = history,
                    selectedHeroId = heroEnum
                )
            }.collect { newState ->
                _uiState.value = newState
            }
        }
    }

    fun navigateTo(state: AppNavState) {
        _uiState.update { it.copy(navState = state) }
        audioSynth.playPickup()
    }

    fun selectHero(heroId: HeroId) {
        viewModelScope.launch {
            repository.setSelectedHero(heroId)
            _uiState.update { it.copy(selectedHeroId = heroId) }
        }
    }

    fun unlockHero(hero: HeroDefinition) {
        viewModelScope.launch {
            repository.unlockHero(hero.id, hero.unlockGoldCost, hero.unlockGemsCost)
            audioSynth.playVictory()
        }
    }

    fun upgradeHeroLevel(heroId: HeroId) {
        viewModelScope.launch {
            val heroProgress = _uiState.value.heroesProgress.find { it.heroId == heroId.name } ?: return@launch
            val cost = heroProgress.level * 150 + 100
            repository.upgradeHeroLevel(heroId, cost)
            audioSynth.playPickup()
        }
    }

    fun promoteHeroStar(heroId: HeroId) {
        viewModelScope.launch {
            val heroProgress = _uiState.value.heroesProgress.find { it.heroId == heroId.name } ?: return@launch
            val cost = heroProgress.starRank * 50
            repository.promoteHeroStar(heroId, cost)
            audioSynth.playVictory()
        }
    }

    fun upgradeLegacy(upgradeId: String) {
        viewModelScope.launch {
            val currentLvl = _uiState.value.legacyList.find { it.upgradeId == upgradeId }?.level ?: 0
            val cost = 100 + currentLvl * 150
            repository.upgradeLegacy(upgradeId, cost)
            audioSynth.playPickup()
        }
    }

    fun equipItem(instanceId: String) {
        viewModelScope.launch {
            repository.equipItem(instanceId)
            audioSynth.playPickup()
        }
    }

    fun upgradeEquipment(instanceId: String) {
        viewModelScope.launch {
            val item = _uiState.value.equipmentList.find { it.instanceId == instanceId } ?: return@launch
            val preset = EquipmentCatalog.ALL_PRESETS.find { it.id == item.itemPresetId } ?: return@launch
            val costGold = item.level * 80 + 50
            val costStones = (item.level / 5) + 1
            repository.upgradeEquipment(instanceId, costGold, costStones)
            audioSynth.playPickup()
        }
    }

    fun mergeEquipment(items: List<UserEquipmentEntity>) {
        if (items.size < 3) return
        val targetSlot = items[0].slot
        val preset = EquipmentCatalog.ALL_PRESETS.find { it.id == items[0].itemPresetId } ?: return
        val nextRarity = when (preset.rarity) {
            Rarity.COMMON -> Rarity.UNCOMMON
            Rarity.UNCOMMON -> Rarity.RARE
            Rarity.RARE -> Rarity.EPIC
            Rarity.EPIC -> Rarity.LEGENDARY
            Rarity.LEGENDARY -> Rarity.MYTHIC
            else -> return
        }
        val upgradedPreset = EquipmentCatalog.ALL_PRESETS.find { it.slot == preset.slot && it.rarity == nextRarity }
            ?: EquipmentCatalog.ALL_PRESETS.filter { it.slot == preset.slot }.random()

        viewModelScope.launch {
            repository.mergeEquipment(items.take(3).map { it.instanceId }, upgradedPreset.id, targetSlot)
            audioSynth.playVictory()
        }
    }

    fun claimAchievement(achievement: AchievementItem) {
        viewModelScope.launch {
            repository.claimAchievement(achievement.id, achievement.rewardGems)
            audioSynth.playVictory()
        }
    }

    fun toggleSound() {
        val next = !_uiState.value.soundEnabled
        _uiState.update { it.copy(soundEnabled = next) }
        audioSynth.isMuted = !next
    }

    fun toggleHaptics() {
        _uiState.update { it.copy(hapticsEnabled = !it.hapticsEnabled) }
    }

    fun toggleScreenShake() {
        _uiState.update { it.copy(screenShakeEnabled = !it.screenShakeEnabled) }
    }

    fun toggleAutoAim() {
        _uiState.update { it.copy(autoAimEnabled = !it.autoAimEnabled) }
    }

    fun toggleLeftHanded() {
        _uiState.update { it.copy(isLeftHanded = !it.isLeftHanded) }
    }

    private fun triggerHaptic(durationMs: Long) {
        if (!_uiState.value.hapticsEnabled || vibrator == null || !vibrator.hasVibrator()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    // Start Real-Time Game Run
    fun startNewRun(heroId: HeroId = _uiState.value.selectedHeroId) {
        val heroDef = HeroCatalog.getHero(heroId)
        val heroProgress = _uiState.value.heroesProgress.find { it.heroId == heroId.name }
        val equippedEntities = _uiState.value.equipmentList.filter { it.isEquipped }
        val equippedItems = equippedEntities.mapNotNull { userEq ->
            val preset = EquipmentCatalog.ALL_PRESETS.find { it.id == userEq.itemPresetId }
            preset?.copy(level = userEq.level)
        }
        val legacyMap = _uiState.value.legacyList.associate { it.upgradeId to it.level }

        activeEngine = GameEngine(
            hero = heroDef,
            heroLevel = heroProgress?.level ?: 1,
            heroStar = heroProgress?.starRank ?: 1,
            equippedItems = equippedItems,
            legacyUpgrades = legacyMap,
            audioSynth = audioSynth,
            onVibrate = { duration -> triggerHaptic(duration) }
        )

        _uiState.update { it.copy(navState = AppNavState.IN_GAME) }
        startGameLoop()
    }

    private fun startGameLoop() {
        gameLoopJob?.cancel()
        gameLoopJob = viewModelScope.launch {
            var lastTime = System.currentTimeMillis()
            while (isActive && activeEngine != null) {
                val now = System.currentTimeMillis()
                val delta = (now - lastTime).coerceIn(1L, 100L)
                lastTime = now

                activeEngine?.let { engine ->
                    engine.update(delta / 1000f)
                    _uiState.update { it.copy(engineStateVersion = it.engineStateVersion + 1) }

                    // Check run completion
                    if (engine.state == GameScreenState.VICTORY ||
                        engine.state == GameScreenState.DEFEAT
                    ) {
                        val isVictory = engine.state == GameScreenState.VICTORY
                        val summary = engine.generateRunSummary(isVictory)
                        _uiState.update { it.copy(lastRunSummary = summary) }
                        repository.recordCompletedRun(summary)
                        gameLoopJob?.cancel()
                    }
                }

                delay(16L) // ~60 FPS
            }
        }
    }

    fun onEndRunReturnToHub() {
        gameLoopJob?.cancel()
        activeEngine = null
        navigateTo(AppNavState.HUB_WORLD)
    }

    override fun onCleared() {
        super.onCleared()
        gameLoopJob?.cancel()
    }
}
