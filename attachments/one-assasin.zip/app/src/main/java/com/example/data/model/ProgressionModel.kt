package com.example.data.model

data class LegacyUpgrade(
    val id: String,
    val name: String,
    val description: String,
    val iconEmoji: String,
    val maxLevel: Int = 10,
    var currentLevel: Int = 0,
    val baseGoldCost: Int = 100,
    val goldCostPerLevel: Int = 150,
    val effectPerLevelString: String
) {
    val currentCost: Int get() = baseGoldCost + currentLevel * goldCostPerLevel
    val isMaxed: Boolean get() = currentLevel >= maxLevel
}

data class DailyMission(
    val id: String,
    val title: String,
    val description: String,
    val iconEmoji: String,
    val targetCount: Int,
    var currentCount: Int = 0,
    val rewardGold: Int,
    val rewardGems: Int,
    var isClaimed: Boolean = false
) {
    val isCompleted: Boolean get() = currentCount >= targetCount
}

data class AchievementItem(
    val id: String,
    val title: String,
    val description: String,
    val iconEmoji: String,
    val targetCount: Int,
    var currentCount: Int = 0,
    val rewardGems: Int,
    var isClaimed: Boolean = false
) {
    val isCompleted: Boolean get() = currentCount >= targetCount
}

data class RunSummary(
    val heroName: String,
    val durationSeconds: Long,
    val enemiesDefeated: Int,
    val bossesDefeated: Int,
    val totalDamageDealt: Long,
    val maxCombo: Int,
    val goldCollected: Int,
    val gemsCollected: Int,
    val blessingsCount: Int,
    val finalScore: Long,
    val isVictory: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

object ProgressionCatalog {
    fun getDefaultLegacyUpgrades(): List<LegacyUpgrade> = listOf(
        LegacyUpgrade("leg_vitality", "Titan Constitution", "Increases Base Max HP by +10 per level.", "❤️", 10, 0, 100, 150, "+10 Max HP"),
        LegacyUpgrade("leg_edge", "Razor Sharpness", "Increases Base Attack Damage by +3 per level.", "🗡️", 10, 0, 150, 200, "+3 Attack"),
        LegacyUpgrade("leg_precision", "Deadly Instinct", "Increases Critical Chance by +1.5% per level.", "🎯", 10, 0, 200, 250, "+1.5% Crit Chance"),
        LegacyUpgrade("leg_wealth", "Plunderer's Eye", "Increases Gold dropped by enemies by +5% per level.", "🪙", 10, 0, 100, 120, "+5% Gold Gain"),
        LegacyUpgrade("leg_swift", "Shadow Momentum", "Reduces Dash Cooldown by 3% per level.", "👟", 10, 0, 180, 220, "-3% Dash CD"),
        LegacyUpgrade("leg_scavenger", "Relic Hunter", "Increases equipment and blessing drop rates by +3% per level.", "💎", 10, 0, 250, 300, "+3% Drop Rate")
    )

    fun getDefaultDailyMissions(): List<DailyMission> = listOf(
        DailyMission("daily_login", "Daily Vow", "Log in and prepare for the hunt.", "📜", 1, 1, 150, 10),
        DailyMission("daily_kills", "Cull the Swarm", "Defeat 30 enemies in the dungeons.", "⚔️", 30, 0, 300, 15),
        DailyMission("daily_boss", "Giant Slayer", "Defeat 1 Miniboss or Guardian.", "👑", 1, 0, 500, 25),
        DailyMission("daily_blessings", "Favor of Gods", "Collect 5 Blessings during runs.", "✨", 5, 0, 250, 15),
        DailyMission("daily_dash", "Ghost Dancer", "Perform 25 dashes in combat.", "💨", 25, 0, 200, 10)
    )

    fun getDefaultAchievements(): List<AchievementItem> = listOf(
        AchievementItem("ach_first_blood", "First Blood", "Defeat your first enemy in the dungeon.", "🩸", 1, 0, 20),
        AchievementItem("ach_gatekeeper", "Gatebreaker", "Defeat The Gatekeeper and conquer the first biome.", "💀", 1, 0, 50),
        AchievementItem("ach_combo_master", "Combo Virtuoso", "Reach a 30-hit combo streak.", "⚡", 30, 0, 30),
        AchievementItem("ach_speed_demon", "Lightning Stride", "Clear a combat room in under 15 seconds.", "⏱️", 1, 0, 35),
        AchievementItem("ach_blessing_collector", "Divine Pantheon", "Collect 10 Blessings in a single run.", "🌟", 10, 0, 40),
        AchievementItem("ach_synergy_master", "Forbidden Alchemist", "Trigger a secret Blessing Synergy combination.", "🌌", 1, 0, 60),
        AchievementItem("ach_no_hit_boss", "Untouchable", "Defeat a boss without taking any damage.", "🛡️", 1, 0, 80),
        AchievementItem("ach_rich", "Hoard of Shadows", "Accumulate 2,000 total Gold.", "💰", 2000, 0, 40),
        AchievementItem("ach_forge_master", "Master Blacksmith", "Upgrade any piece of equipment to Level 5.", "🔨", 5, 0, 35),
        AchievementItem("ach_hero_collector", "Guild of Assassins", "Unlock all heroes in the roster.", "🥷", 5, 1, 100)
    )
}
