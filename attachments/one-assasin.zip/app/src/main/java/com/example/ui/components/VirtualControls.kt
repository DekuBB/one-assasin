package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.Direction
import com.example.engine.GameEngine
import com.example.ui.theme.TextWhite
import kotlin.math.abs
import kotlin.math.ceil

@Composable
fun VirtualControls(
    engine: GameEngine,
    modifier: Modifier = Modifier
) {
    val hero = engine.hero
    val now = System.currentTimeMillis()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // SKILL STATUS BARS PANEL (Guidus style metal status panel)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF10172A), RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFF454050), RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Primary Skill Bar
            val pCdLeft = ((engine.primaryReadyAt - now).toFloat() / hero.skill1.cooldownMs).coerceIn(0f, 1f)
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = hero.skill1.name.uppercase(),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF1DFC4)
                    )
                    Text(
                        text = if (pCdLeft > 0f) "${ceil((engine.primaryReadyAt - now) / 1000f).toInt()}s" else "GOTOWE",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (pCdLeft > 0f) Color(0xFFB4A9BB) else Color(0xFFA7F3AC)
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color(0xFF26324A))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(1f - pCdLeft)
                            .background(hero.primaryColor)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Secondary Skill Bar
            val sCdLeft = ((engine.secondaryReadyAt - now).toFloat() / hero.skill2.cooldownMs).coerceIn(0f, 1f)
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = hero.skill2.name.uppercase(),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF1DFC4)
                    )
                    Text(
                        text = if (sCdLeft > 0f) "${ceil((engine.secondaryReadyAt - now) / 1000f).toInt()}s" else "GOTOWE",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (sCdLeft > 0f) Color(0xFFB4A9BB) else Color(0xFFA7F3AC)
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color(0xFF26324A))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(1f - sCdLeft)
                            .background(hero.glowColor)
                    )
                }
            }
        }

        // D-PAD & SKILL BUTTONS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // D-PAD (4 Directions with center hub)
            Box(
                modifier = Modifier
                    .size(136.dp)
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                val dir = getDirectionFromOffset(offset.x, offset.y, 136f)
                                engine.heldDirection = dir
                                if (dir != null) engine.movePlayer(dir)
                            },
                            onDrag = { change, _ ->
                                val dir = getDirectionFromOffset(change.position.x, change.position.y, 136f)
                                engine.heldDirection = dir
                                if (dir != null) engine.movePlayer(dir)
                            },
                            onDragEnd = { engine.heldDirection = null },
                            onDragCancel = { engine.heldDirection = null }
                        )
                    }
                    .testTag("dpad_controller"),
                contentAlignment = Alignment.Center
            ) {
                // Up Button
                DPadArrowButton(
                    direction = Direction.UP,
                    isHeld = engine.heldDirection == Direction.UP,
                    onPress = {
                        engine.heldDirection = Direction.UP
                        engine.movePlayer(Direction.UP)
                    },
                    onRelease = { engine.heldDirection = null },
                    modifier = Modifier.align(Alignment.TopCenter)
                )

                // Down Button
                DPadArrowButton(
                    direction = Direction.DOWN,
                    isHeld = engine.heldDirection == Direction.DOWN,
                    onPress = {
                        engine.heldDirection = Direction.DOWN
                        engine.movePlayer(Direction.DOWN)
                    },
                    onRelease = { engine.heldDirection = null },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )

                // Left Button
                DPadArrowButton(
                    direction = Direction.LEFT,
                    isHeld = engine.heldDirection == Direction.LEFT,
                    onPress = {
                        engine.heldDirection = Direction.LEFT
                        engine.movePlayer(Direction.LEFT)
                    },
                    onRelease = { engine.heldDirection = null },
                    modifier = Modifier.align(Alignment.CenterStart)
                )

                // Right Button
                DPadArrowButton(
                    direction = Direction.RIGHT,
                    isHeld = engine.heldDirection == Direction.RIGHT,
                    onPress = {
                        engine.heldDirection = Direction.RIGHT
                        engine.movePlayer(Direction.RIGHT)
                    },
                    onRelease = { engine.heldDirection = null },
                    modifier = Modifier.align(Alignment.CenterEnd)
                )

                // Center Hub
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF17213C))
                        .border(1.dp, Color(0xFF334466), RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "◆",
                        color = Color(0xFF7890C4),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // RIGHT ACTION BUTTONS: Skill I (Q) & Skill II (E)
            Row(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Skill I
                val pCooldown = engine.primaryReadyAt > now
                SkillRoundButton(
                    shortcutKey = "Q",
                    label = "I",
                    iconEmoji = hero.skill1.iconEmoji,
                    isCoolingDown = pCooldown,
                    cooldownPercent = if (pCooldown) ((engine.primaryReadyAt - now).toFloat() / hero.skill1.cooldownMs).coerceIn(0f, 1f) else 0f,
                    activeColor = hero.primaryColor,
                    onClick = { engine.usePrimarySkill() },
                    testTag = "btn_skill_primary"
                )

                // Skill II
                val sCooldown = engine.secondaryReadyAt > now
                SkillRoundButton(
                    shortcutKey = "E",
                    label = "II",
                    iconEmoji = hero.skill2.iconEmoji,
                    isCoolingDown = sCooldown,
                    cooldownPercent = if (sCooldown) ((engine.secondaryReadyAt - now).toFloat() / hero.skill2.cooldownMs).coerceIn(0f, 1f) else 0f,
                    activeColor = hero.glowColor,
                    onClick = { engine.useSecondarySkill() },
                    testTag = "btn_skill_secondary"
                )
            }
        }
    }
}

private fun getDirectionFromOffset(x: Float, y: Float, boxSize: Float): Direction? {
    val center = boxSize / 2f
    val dx = x - center
    val dy = y - center
    if (abs(dx) < 18f && abs(dy) < 18f) return null
    return if (abs(dx) > abs(dy)) {
        if (dx > 0) Direction.RIGHT else Direction.LEFT
    } else {
        if (dy > 0) Direction.DOWN else Direction.UP
    }
}

@Composable
fun DPadArrowButton(
    direction: Direction,
    isHeld: Boolean,
    onPress: () -> Unit,
    onRelease: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(42.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isHeld) Color(0xFFA9505F) else Color(0xFF26324D))
            .border(1.5.dp, if (isHeld) Color(0xFFF1BE85) else Color(0xFF647495), RoundedCornerShape(8.dp))
            .pointerInput(direction) {
                detectTapGestures(
                    onPress = {
                        onPress()
                        tryAwaitRelease()
                        onRelease()
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = direction.icon,
            fontSize = 16.sp,
            fontWeight = FontWeight.Black,
            color = if (isHeld) Color(0xFFFFF1D0) else Color(0xFFB3C3E2)
        )
    }
}

@Composable
fun SkillRoundButton(
    shortcutKey: String,
    label: String,
    iconEmoji: String,
    isCoolingDown: Boolean,
    cooldownPercent: Float,
    activeColor: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(if (isCoolingDown) Color(0xFF242B45) else activeColor)
                .border(2.dp, if (isCoolingDown) Color(0xFF5E6D9A) else Color(0xFFF7E1B7), CircleShape)
                .pointerInput(testTag) {
                    detectTapGestures(onTap = { onClick() })
                }
                .testTag(testTag),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = shortcutKey,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = if (isCoolingDown) Color(0xFF8390B9) else Color(0xFF1B2036)
                )
                Text(
                    text = iconEmoji,
                    fontSize = 11.sp
                )
            }
        }

        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFB9C6E7)
        )
    }
}
