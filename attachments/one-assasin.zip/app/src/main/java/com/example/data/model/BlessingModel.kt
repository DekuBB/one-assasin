package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class Rarity(val label: String, val color: Color) {
    COMMON("Zwykłe", RarityCommon),
    UNCOMMON("Niezwykłe", RarityUncommon),
    RARE("Rzadkie", RarityRare),
    EPIC("Epickie", RarityEpic),
    LEGENDARY("Legendarne", RarityLegendary),
    MYTHIC("Mityczne", RarityMythic),
    FORBIDDEN("Zakazane", RarityForbidden)
}

data class Blessing(
    val id: String,
    val name: String,
    val description: String,
    val rarity: Rarity,
    val iconEmoji: String,
    val attackBonus: Float = 0f,
    val hpBonus: Float = 0f,
    val healAmount: Float = 0f,
    val speedMultiplier: Float = 1f,
    val critBonus: Float = 0f,
    val skillPowerBonus: Float = 0f,
    val armorBonus: Float = 0f,
    val supernovaChanceBonus: Float = 0f,
    val ignitionChance: Float = 0f
)

data class BlessingSynergy(
    val id: String,
    val name: String,
    val description: String,
    val requiredBlessingIds: List<String>,
    val synergyBlessing: Blessing
)

data class Curse(
    val id: String,
    val name: String,
    val description: String,
    val penaltyDescription: String
)

object BlessingCatalog {
    val MOON_BLADE = Blessing(
        id = "fang",
        name = "Ostrze księżyca",
        description = "+5 obrażeń podstawowego ataku.",
        rarity = Rarity.COMMON,
        iconEmoji = "🗡️",
        attackBonus = 5f
    )

    val RED_ELIXIR = Blessing(
        id = "heart",
        name = "Czerwony eliksir",
        description = "+26 maks. zdrowia i natychmiastowe leczenie.",
        rarity = Rarity.UNCOMMON,
        iconEmoji = "❤️",
        hpBonus = 26f,
        healAmount = 38f
    )

    val SWIFT_STEP = Blessing(
        id = "wind",
        name = "Lekki krok",
        description = "Ruch o 18% szybszy (skraca opóźnienie kroku).",
        rarity = Rarity.RARE,
        iconEmoji = "👟",
        speedMultiplier = 0.82f
    )

    val HUNTER_EYE = Blessing(
        id = "focus",
        name = "Oko łowcy",
        description = "+12% szansy na cios krytyczny.",
        rarity = Rarity.RARE,
        iconEmoji = "🎯",
        critBonus = 0.12f
    )

    val RUNE_EMBER = Blessing(
        id = "ember",
        name = "Żar runy",
        description = "Umiejętności zadają +35% obrażeń.",
        rarity = Rarity.EPIC,
        iconEmoji = "🔥",
        skillPowerBonus = 0.35f
    )

    val ASH_CLOAK = Blessing(
        id = "ward",
        name = "Płaszcz z popiołu",
        description = "-1 obrażeń od zwykłych wrogów.",
        rarity = Rarity.UNCOMMON,
        iconEmoji = "🛡️",
        armorBonus = 1f
    )

    val SUPERNOVA = Blessing(
        id = "supernova",
        name = "Supernova",
        description = "Ruch ma szansę wyzwolić falę uderzeniową raniącą pobliskich wrogów.",
        rarity = Rarity.LEGENDARY,
        iconEmoji = "☀️",
        supernovaChanceBonus = 0.15f
    )

    val IGNITION = Blessing(
        id = "ignition",
        name = "Ignition",
        description = "Ataki podstawowe mają szansę podpalić wrogów za ciągłe obrażenia.",
        rarity = Rarity.EPIC,
        iconEmoji = "💥",
        ignitionChance = 0.25f
    )

    val THUNDER_STRIKE = Blessing(
        id = "thunder",
        name = "Błyskawica Zeusa",
        description = "Poraża łukiem elektrycznym sąsiednich wrogów.",
        rarity = Rarity.EPIC,
        iconEmoji = "⚡",
        attackBonus = 3f
    )

    val ALL_STANDARD = listOf(
        MOON_BLADE,
        RED_ELIXIR,
        SWIFT_STEP,
        HUNTER_EYE,
        RUNE_EMBER,
        ASH_CLOAK,
        SUPERNOVA,
        IGNITION,
        THUNDER_STRIKE
    )

    val SYNERGIES = listOf(
        BlessingSynergy(
            id = "solar_flare",
            name = "Słoneczny Rozbłysk",
            description = "Supernova oraz Podpalenie tworzą niszczycielskie eksplozje plazmowe.",
            requiredBlessingIds = listOf("supernova", "ignition"),
            synergyBlessing = Blessing(
                id = "syn_solar_flare",
                name = "Słoneczny Rozbłysk",
                description = "Automatyczne eksplozje ognia wokół gracza.",
                rarity = Rarity.FORBIDDEN,
                iconEmoji = "🌟",
                attackBonus = 12f,
                supernovaChanceBonus = 0.25f
            )
        ),
        BlessingSynergy(
            id = "shadow_reaper",
            name = "Żniwiarz Cieni",
            description = "Ostrze Księżyca + Oko Łowcy gwarantuje 250% obrażeń krytycznych.",
            requiredBlessingIds = listOf("fang", "focus"),
            synergyBlessing = Blessing(
                id = "syn_shadow_reaper",
                name = "Żniwiarz Cieni",
                description = "Ekstremalne obrażenia krytyczne i natychmiastowe egzekucje.",
                rarity = Rarity.FORBIDDEN,
                iconEmoji = "💀",
                attackBonus = 10f,
                critBonus = 0.20f
            )
        )
    )
}

object CurseCatalog {
    val ALL = listOf(
        Curse(
            id = "curse_blood",
            name = "Klątwa Krwi",
            description = "Wrogowie mają +25% zdrowia.",
            penaltyDescription = "+25% HP potworów"
        ),
        Curse(
            id = "curse_decay",
            name = "Rozpad Pancerza",
            description = "Otrzymujesz +2 obrażenia więcej od ataków.",
            penaltyDescription = "-2 Pancerza"
        )
    )
}
