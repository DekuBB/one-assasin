package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class RoomType(
    val title: String,
    val iconEmoji: String,
    val color: Color,
    val description: String
) {
    COMBAT("Battle Room", "⚔️", CrimsonBlade, "Standard monster lair. Defeat all enemies to proceed."),
    ELITE("Elite Trial", "👑", FlameOrange, "Dangerous elite warriors guarding rich treasures."),
    TREASURE("Treasure Vault", "💎", GoldSun, "Ancient chests containing gold, gems, or equipment."),
    SHOP("Merchant Outpost", "🛒", EmeraldGreen, "Purchase healing, blessings, and rare gear."),
    SHRINE("Ancient Shrine", "🔥", VoidAmethyst, "Offer gold or blood for divine blessings."),
    EVENT("Fate Encounter", "❓", NeonCyan, "Mysterious stranger offers fateful choices."),
    TRAP("Hazard Chamber", "☣️", PoisonGreen, "Traps and spikes. High risk, bonus rewards."),
    HEAL("Vitality Spring", "💚", EmeraldGreen, "Rest and recover your wounds."),
    BOSS("Gate of the Guardian", "💀", CrimsonBlade, "Epic boss battle protecting the deeper abyss.")
}

enum class Biome(
    val title: String,
    val subtitle: String,
    val floorColor: Color,
    val wallColor: Color,
    val accentColor: Color,
    val ambientDescription: String
) {
    FORGOTTEN_CITADEL(
        "Forgotten Citadel",
        "Ancient stone ruins of the Old Empire",
        DungeonSlate,
        DungeonBorder,
        NeonCyan,
        "Cold winds whistle through broken arches..."
    ),
    BLOOD_FOREST(
        "Blood Forest",
        "Crimson flora drenched in dark essence",
        Color(0xFF241016),
        Color(0xFF3F131D),
        CrimsonBlade,
        "Red leaves rustle with the whispers of fallen spirits..."
    ),
    FROZEN_ABYSS(
        "Frozen Abyss",
        "Glacial depths of eternal frost",
        Color(0xFF0F1E2E),
        Color(0xFF1B3B59),
        FrostCyan,
        "Sub-zero winds chill your very blades..."
    ),
    EMBER_FORTRESS(
        "Ember Fortress",
        "Volcanic stronghold surrounded by magma",
        Color(0xFF2E150B),
        Color(0xFF4D2411),
        FlameOrange,
        "Boiling heat ripples through molten iron corridors..."
    ),
    VOID_SANCTUM(
        "Void Sanctum",
        "Cosmic reality distortion",
        Color(0xFF140D26),
        Color(0xFF2A1B4E),
        VoidAmethyst,
        "Gravitational rifts tear at the fabric of space..."
    )
}

data class DungeonNode(
    val floor: Int,
    val index: Int,
    val roomType: RoomType,
    val biome: Biome,
    val nextNodeIndices: List<Int>,
    var isCleared: Boolean = false,
    var isCurrent: Boolean = false,
    val enemyCount: Int = 3
)

data class DungeonFloorPlan(
    val biome: Biome,
    val nodes: List<List<DungeonNode>>,
    var currentFloorIndex: Int = 0,
    var currentNodeIndex: Int = 0
)

data class GameEventChoice(
    val text: String,
    val outcomeDescription: String,
    val karmaDelta: Int,
    val goldDelta: Int = 0,
    val hpDeltaPercent: Float = 0f,
    val grantBlessing: Blessing? = null,
    val grantGems: Int = 0
)

data class GameEvent(
    val id: String,
    val title: String,
    val speaker: String,
    val dialog: String,
    val iconEmoji: String,
    val choices: List<GameEventChoice>
)

object EventCatalog {
    val MYSTERIOUS_WITCH = GameEvent(
        id = "witch_choice",
        title = "The Mysterious Witch",
        speaker = "Veiled Sorceress",
        dialog = "\"Every step into the darkness leaves a mark on the soul. What will you offer to change your destiny, Assassin?\"",
        iconEmoji = "🧙‍♀️",
        choices = listOf(
            GameEventChoice(
                text = "Offer 100 Gold for Safe Passage",
                outcomeDescription = "The witch smiles and bestows a protective blessing upon you.",
                karmaDelta = 1,
                goldDelta = -100,
                grantBlessing = BlessingCatalog.RED_ELIXIR
            ),
            GameEventChoice(
                text = "Offer Blood (Lose 20% HP)",
                outcomeDescription = "The witch consumes your vitality and hands you a dark talisman.",
                karmaDelta = -1,
                hpDeltaPercent = -0.20f,
                grantBlessing = BlessingCatalog.MOON_BLADE
            ),
            GameEventChoice(
                text = "Politely Walk Away",
                outcomeDescription = "You decline her offers and continue on your journey.",
                karmaDelta = 0
            )
        )
    )

    val LOST_BLACKSMITH = GameEvent(
        id = "lost_blacksmith",
        title = "Wandering Armorer",
        speaker = "Master Forger",
        dialog = "\"I can temper your blade with starlight, or quench it in shadow. Which path do you walk?\"",
        iconEmoji = "🔨",
        choices = listOf(
            GameEventChoice(
                text = "Temper with Starlight (+Holy Aura)",
                outcomeDescription = "Your weapons radiate with pure celestial power.",
                karmaDelta = 2,
                goldDelta = -50,
                grantBlessing = BlessingCatalog.SWIFT_STEP
            ),
            GameEventChoice(
                text = "Quench in Shadow (+Toxic Needle)",
                outcomeDescription = "Dark poison drips continuously from your edge.",
                karmaDelta = -1,
                grantBlessing = BlessingCatalog.MOON_BLADE
            ),
            GameEventChoice(
                text = "Share Supplies (+50 HP)",
                outcomeDescription = "You share rations with the tired craftsman.",
                karmaDelta = 2,
                hpDeltaPercent = 0.35f
            )
        )
    )

    val ALL = listOf(MYSTERIOUS_WITCH, LOST_BLACKSMITH)
}
