package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.HeroCatalog
import com.example.ui.AppNavState
import com.example.ui.GameViewModel
import com.example.ui.theme.*

@Composable
fun MainMenuScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val currentHero = HeroCatalog.getHero(uiState.selectedHeroId)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B1020))
            .verticalScroll(rememberScrollState())
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // TOP CURRENCY BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF10172B), RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFF252F51), RoundedCornerShape(12.dp))
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🪙", fontSize = 14.sp)
                Text(
                    text = "${uiState.profile.gold}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFFF5C65A)
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("💎", fontSize = 14.sp)
                Text(
                    text = "${uiState.profile.gems}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF8EE7E2)
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("⛏️", fontSize = 14.sp)
                Text(
                    text = "${uiState.profile.catalystStones}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFFDCA3E8)
                )
            }
        }

        // MAIN TITLE PANEL (Matching index.html & styles.css)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF151E38)),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.verticalGradient(listOf(Color(0xFFA25460), Color(0xFF30223D)))
            )
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "KAFELKOWE ACTION ROGUELIKE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp,
                    color = Color(0xFF83E9E0)
                )

                Text(
                    text = "ONE ASSASIN",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFFEDF0E8),
                    letterSpacing = 2.sp
                )

                Text(
                    text = "Odbij królewski pałac. Każdy ruch ma znaczenie.",
                    fontSize = 12.sp,
                    color = Color(0xFFC0C9E6),
                    textAlign = TextAlign.Center
                )
            }
        }

        // HERO SELECT CARDS (Radio list)
        Text(
            text = "WYBIERZ BOHATERA",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = TextWhite,
            modifier = Modifier.fillMaxWidth()
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            HeroCatalog.ALL.forEach { hero ->
                val isSelected = hero.id == currentHero.id
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectHero(hero.id) }
                        .testTag("hero_radio_${hero.id.name.lowercase()}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFF34243F) else Color(0xFF151E38)
                    ),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = if (isSelected) Brush.horizontalGradient(listOf(Color(0xFFF37464), Color(0xFFE971A8)))
                        else Brush.horizontalGradient(listOf(Color(0xFF525E8D), Color(0xFF26324A)))
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(hero.primaryColor.copy(alpha = 0.25f))
                                .border(1.dp, hero.primaryColor, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = hero.iconEmoji, fontSize = 18.sp, color = hero.glowColor)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = hero.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    color = TextWhite
                                )
                                Text(
                                    text = "— ${hero.role}",
                                    fontSize = 12.sp,
                                    color = hero.glowColor
                                )
                            }
                            Text(
                                text = hero.description,
                                fontSize = 10.sp,
                                color = Color(0xFFAAB7D8),
                                lineHeight = 13.sp
                            )
                        }

                        if (isSelected) {
                            Text("✓", fontSize = 16.sp, color = Color(0xFFF37464), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // BIG START BUTTON (Matching index.html & styles.css)
        Button(
            onClick = { viewModel.startNewRun(currentHero.id) },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFF6BD60),
                contentColor = Color(0xFF25141C)
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("btn_start_run")
        ) {
            Text(
                text = "ROZPOCZNIJ WYPRAWĘ",
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
        }

        Text(
            text = "Sterowanie: przeciągaj po krzyżaku lub klikaj kierunki. Umiejętności: przyciski Q i E.",
            fontSize = 10.sp,
            color = Color(0xFF929FCA),
            textAlign = TextAlign.Center
        )

        // HUB QUICK ACCESS BUTTONS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = { viewModel.navigateTo(AppNavState.EQUIPMENT_FORGE) },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDCE7FF)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).testTag("btn_menu_forge")
            ) {
                Text("⚒️ Ekwipunek", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = { viewModel.navigateTo(AppNavState.LEGACY_ALTAR) },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDCE7FF)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).testTag("btn_menu_altar")
            ) {
                Text("🏛️ Ołtarz Run", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = { viewModel.navigateTo(AppNavState.SETTINGS) },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDCE7FF)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).testTag("btn_menu_settings")
            ) {
                Text("⚙️ Opcje", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
