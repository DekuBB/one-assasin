package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HeroCatalog
import com.example.data.model.HeroDefinition
import com.example.ui.AppNavState
import com.example.ui.GameViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HeroSelectScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val allHeroes = HeroCatalog.ALL

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ASSASSIN GUILD ROSTER", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(AppNavState.MAIN_MENU) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianDark)
            )
        },
        containerColor = VoidBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(allHeroes) { hero ->
                val progress = uiState.heroesProgress.find { it.heroId == hero.id.name }
                val isUnlocked = progress?.isUnlocked ?: (hero.id.name == "NYRA")
                val isSelected = uiState.selectedHeroId == hero.id
                val currentLevel = progress?.level ?: 1
                val starRank = progress?.starRank ?: 1

                HeroRosterCard(
                    hero = hero,
                    isUnlocked = isUnlocked,
                    isSelected = isSelected,
                    level = currentLevel,
                    starRank = starRank,
                    gold = uiState.profile.gold,
                    gems = uiState.profile.gems,
                    onSelect = { viewModel.selectHero(hero.id) },
                    onUnlock = { viewModel.unlockHero(hero) },
                    onLevelUp = { viewModel.upgradeHeroLevel(hero.id) },
                    onPromote = { viewModel.promoteHeroStar(hero.id) }
                )
            }
        }
    }
}

@Composable
fun HeroRosterCard(
    hero: HeroDefinition,
    isUnlocked: Boolean,
    isSelected: Boolean,
    level: Int,
    starRank: Int,
    gold: Int,
    gems: Int,
    onSelect: () -> Unit,
    onUnlock: () -> Unit,
    onLevelUp: () -> Unit,
    onPromote: () -> Unit
) {
    val levelCost = level * 150 + 100
    val starCost = starRank * 50

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hero_card_${hero.id.name.lowercase()}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) ObsidianDark else DungeonSlate
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = if (isSelected) Brush.horizontalGradient(listOf(hero.primaryColor, hero.accentColor))
            else Brush.horizontalGradient(listOf(DungeonBorder, DungeonBorder))
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header: Avatar, Name, Title, Rank
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(hero.primaryColor)
                        .border(2.dp, hero.accentColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = hero.avatarEmoji, fontSize = 28.sp)
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = hero.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                        if (isUnlocked) {
                            Text(
                                text = "★".repeat(starRank),
                                fontSize = 13.sp,
                                color = GoldSun
                            )
                        }
                    }
                    Text(
                        text = hero.title,
                        fontSize = 12.sp,
                        color = hero.accentColor
                    )
                    Text(
                        text = hero.role,
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }

                if (isUnlocked) {
                    if (isSelected) {
                        Badge(containerColor = CrimsonBlade) {
                            Text("ACTIVE", color = TextWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                        }
                    } else {
                        Button(
                            onClick = onSelect,
                            colors = ButtonDefaults.buttonColors(containerColor = DungeonBorder),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("SELECT", fontSize = 11.sp)
                        }
                    }
                }
            }

            // Passive and Skills Breakdown
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x33000000), RoundedCornerShape(8.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "PASSIVE: ${hero.passiveName}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoldSun
                )
                Text(
                    text = hero.passiveDescription,
                    fontSize = 11.sp,
                    color = TextMuted
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "SKILLS: ${hero.skill1.name} (${hero.skill1.iconEmoji}) [Q] • ${hero.skill2.name} (${hero.skill2.iconEmoji}) [E]",
                    fontSize = 10.sp,
                    color = NeonCyan
                )
            }

            // Stats row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Text("HP: ${(hero.baseHp * (1f + (starRank - 1) * 0.15f) * (1f + (level - 1) * 0.05f)).toInt()}", fontSize = 11.sp, color = TextWhite)
                Text("ATK: ${(hero.baseAttack * (1f + (starRank - 1) * 0.15f) * (1f + (level - 1) * 0.05f)).toInt()}", fontSize = 11.sp, color = CrimsonBlade)
                Text("DEF: ${(hero.baseDefense * (1f + (starRank - 1) * 0.15f)).toInt()}", fontSize = 11.sp, color = ElectricBlue)
                Text("CRIT: ${(hero.baseCritChance * 100).toInt()}%", fontSize = 11.sp, color = GoldSun)
            }

            // Action Row: Unlock or Upgrade
            if (!isUnlocked) {
                Button(
                    onClick = onUnlock,
                    enabled = gold >= hero.unlockGoldCost && gems >= hero.unlockGemsCost,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldSun),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "UNLOCK FOR ${hero.unlockGoldCost} 🪙 + ${hero.unlockGemsCost} 💎",
                        color = ObsidianDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onLevelUp,
                        enabled = gold >= levelCost,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = DungeonBorder),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("LV. UP (Lv.$level) $levelCost🪙", fontSize = 10.sp, color = TextWhite)
                    }

                    Button(
                        onClick = onPromote,
                        enabled = gems >= starCost && starRank < 5,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = VoidAmethyst),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            if (starRank < 5) "PROMOTE ($starCost 💎)" else "MAX STAR",
                            fontSize = 10.sp,
                            color = TextWhite
                        )
                    }
                }
            }
        }
    }
}
